// Unwip (PC) - the optional natural voice (Kokoro). Nothing of it ships with Unwip: when you ask for it, the
// files are downloaded from their own public homes (the npm registry's CDN and Hugging Face), each one checked
// against a known fingerprint, and kept in Unwip's data folder. After that it works offline.
// It runs in its own hidden window, set up so the speech engine may use several processor cores.
'use strict';
const { app, BrowserWindow, ipcMain, protocol, net } = require('electron');
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const { FILES } = require('../kokoro-files.js');   // the same list the web version uses
const TOTAL = FILES.reduce((a, f) => a + f[3], 0);
const SCHEME = 'unwip-voice';
const DIR = () => path.join(app.getPath('userData'), 'kokoro');
const MIME = { js: 'text/javascript', mjs: 'text/javascript', wasm: 'application/wasm', json: 'application/json', html: 'text/html', onnx: 'application/octet-stream', bin: 'application/octet-stream' };

// must run before the app is ready
protocol.registerSchemesAsPrivileged([{ scheme: SCHEME, privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }]);

function installed() { return FILES.every(([f, , , size]) => { try { return fs.statSync(path.join(DIR(), f)).size === size; } catch { return false; } }); }

let voiceWin = null, ready = null, seq = 0;
const waiting = new Map();
function voiceWindow() {
  if (voiceWin && !voiceWin.isDestroyed()) return ready;
  voiceWin = new BrowserWindow({ show: false, webPreferences: { preload: path.join(__dirname, 'voice-preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false } });
  ready = new Promise((res, rej) => {
    const t = setTimeout(() => rej(new Error('The voice took too long to start.')), 120000);
    waiting.set('ready', { res: v => { clearTimeout(t); res(v); }, rej: e => { clearTimeout(t); rej(e); } });
  });
  voiceWin.on('closed', () => { voiceWin = null; for (const [, w] of waiting) w.rej(new Error('The voice stopped.')); waiting.clear(); ready = null; });
  voiceWin.loadURL(`${SCHEME}://app/voice.html`);
  return ready;
}
function stopVoice() { if (voiceWin && !voiceWin.isDestroyed()) voiceWin.destroy(); voiceWin = null; ready = null; }

async function download(onProgress) {
  const dir = DIR(); fs.mkdirSync(path.join(dir, 'onnx'), { recursive: true }); fs.mkdirSync(path.join(dir, 'voices'), { recursive: true });
  let done = 0;
  for (const [file, url, sha, size] of FILES) {
    const dest = path.join(dir, file);
    try { if (fs.statSync(dest).size === size) { done += size; onProgress(done, TOTAL, file); continue; } } catch {}
    const base = process.env.UNWIP_KOKORO_MIRROR;   // tests only: a local copy of the same files
    const res = await net.fetch(base ? base + file : url);
    if (!res.ok) throw new Error(`Couldn’t download ${file} (${res.status}).`);
    const hash = crypto.createHash('sha256'), tmp = dest + '.part', out = fs.createWriteStream(tmp);
    const reader = res.body.getReader(); let got = 0;
    for (;;) {
      const { done: end, value } = await reader.read(); if (end) break;
      hash.update(value); got += value.length; done += value.length;
      if (!out.write(Buffer.from(value))) await new Promise(r => out.once('drain', r));
      onProgress(Math.min(done, TOTAL), TOTAL, file);
    }
    await new Promise((r, j) => out.end(e => (e ? j(e) : r())));
    if (hash.digest('hex') !== sha || got !== size) { fs.rmSync(tmp, { force: true }); throw new Error(`${file} didn’t match the expected file, so it wasn’t kept. Try again later.`); }
    fs.renameSync(tmp, dest);
  }
}

module.exports = function setup() {
  app.whenReady().then(() => {
    protocol.handle(SCHEME, async req => {
      const u = new URL(req.url); let file = null;
      if (u.host === 'app' && u.pathname.startsWith('/kokoro/')) { const rel = decodeURIComponent(u.pathname.slice(8)); if (FILES.some(f => f[0] === rel)) file = path.join(DIR(), rel); }
      else if (u.host === 'app' && ['/voice.html', '/voice.js'].includes(u.pathname)) file = path.join(__dirname, u.pathname.slice(1));
      const headers = { 'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Embedder-Policy': 'require-corp', 'Cross-Origin-Resource-Policy': 'cross-origin', 'Access-Control-Allow-Origin': '*' };
      if (!file || !fs.existsSync(file)) return new Response('Not found', { status: 404, headers });
      headers['Content-Type'] = MIME[path.extname(file).slice(1)] || 'application/octet-stream';
      let buf = fs.readFileSync(file);
      // the checked library file, plus one line that lets the voice window choose how many processor cores to use
      if (path.basename(file) === 'kokoro.web.js') {
        const t = buf.toString('utf8'), end = 'export{Ef as KokoroTTS,kf as TextSplitterStream,Mf as env};';
        if (t.endsWith(end) || t.includes(end)) buf = Buffer.from(t.replace(end, end + 'export const __onnxWasm=()=>Wg.backends.onnx.wasm;'), 'utf8');
      }
      return new Response(buf, { headers });
    });

  });
  app.on('before-quit', stopVoice);
  // the hidden voice window mustn't keep Unwip running once your windows are closed
  app.on('browser-window-created', (_e, w) => w.on('closed', () => {
    if (w === voiceWin) return;
    if (!BrowserWindow.getAllWindows().some(x => x !== voiceWin && x !== w && !x.isDestroyed())) stopVoice();
  }));

  ipcMain.handle('voice:status', () => ({ installed: installed(), bytes: TOTAL, running: !!voiceWin }));
  ipcMain.handle('voice:install', async e => {
    let last = 0;
    await download((done, total, file) => { const now = Date.now(); if (now - last > 150 || done === total) { last = now; e.sender.send('voice:progress', { done, total, file }); } });
    return { installed: installed() };
  });
  ipcMain.handle('voice:remove', () => { stopVoice(); fs.rmSync(DIR(), { recursive: true, force: true }); return true; });
  // say one sentence: resolves with the sound as 32-bit samples
  ipcMain.handle('voice:speak', async (_e, text, voice, speed) => {
    if (!installed()) throw new Error('The natural voice isn’t downloaded.');
    await voiceWindow();
    const id = ++seq;
    return new Promise((res, rej) => { waiting.set(id, { res, rej }); voiceWin.webContents.send('voice:say', { id, text, voice, speed }); });
  });
  ipcMain.handle('voice:warm', async () => (installed() ? await voiceWindow() : null));
  // messages from the hidden voice window
  ipcMain.on('voice:ready', (_e, info) => { const w = waiting.get('ready'); waiting.delete('ready'); if (w) (info && info.error ? w.rej(new Error(info.error)) : w.res(info)); });
  ipcMain.on('voice:done', (_e, { id, audio, rate, error }) => { const w = waiting.get(id); waiting.delete(id); if (!w) return; error ? w.rej(new Error(error)) : w.res({ audio, rate }); });
};
module.exports.FILES = FILES;

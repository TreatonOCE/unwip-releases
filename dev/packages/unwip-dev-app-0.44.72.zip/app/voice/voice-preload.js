// Unwip (PC) - the hidden natural-voice window talks to the app only through these few messages.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('voiceHost', {
  onSay: cb => ipcRenderer.on('voice:say', (_e, job) => cb(job)),
  ready: info => ipcRenderer.send('voice:ready', info),
  done: msg => ipcRenderer.send('voice:done', msg)
});

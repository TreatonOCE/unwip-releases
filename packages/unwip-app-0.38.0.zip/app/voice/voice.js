// Unwip (PC) - runs in the hidden voice window. Loads the downloaded Kokoro files from this computer and turns
// sentences into sound. It never goes online: the files it asks for are answered from Unwip's data folder.
const K = 'unwip-voice://app/kokoro/';
const MODEL = /^https:\/\/huggingface\.co\/onnx-community\/Kokoro-82M-v1\.0-ONNX\/resolve\/[^/]+\/(.+)$/;
const real = window.fetch.bind(window);
window.fetch = (u, o) => {
  const url = String((u && u.url) || u), m = url.match(MODEL);
  if (m) return real(K + m[1]);
  if (/^https?:/i.test(url)) return Promise.reject(new Error('The voice works offline only.'));
  return real(u, o);
};
let tts = null;
(async () => {
  try {
    const mod = await import(K + 'kokoro.web.js');
    mod.env.wasmPaths = { mjs: K + 'ort-wasm-simd-threaded.jsep.mjs', wasm: K + 'ort-wasm-simd-threaded.jsep.wasm' };
    tts = await mod.KokoroTTS.from_pretrained('onnx-community/Kokoro-82M-v1.0-ONNX', { dtype: 'q8', device: 'wasm' });
    window.voiceHost.ready({ threads: self.crossOriginIsolated, cores: navigator.hardwareConcurrency });
  } catch (e) { window.voiceHost.ready({ error: String((e && e.message) || e) }); }
})();
let chain = Promise.resolve();
window.voiceHost.onSay(job => {
  chain = chain.then(async () => {
    try {
      const a = await tts.generate(job.text, { voice: job.voice || 'bf_emma', speed: job.speed || 1 });
      window.voiceHost.done({ id: job.id, audio: a.audio, rate: a.sampling_rate });
    } catch (e) { window.voiceHost.done({ id: job.id, error: String((e && e.message) || e) }); }
  });
});

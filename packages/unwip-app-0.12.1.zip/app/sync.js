// Unwip - working across devices (Dropbox / OneDrive folders) and backups.
// Sync itself is done by the Dropbox (or OneDrive) app: Unwip keeps its library inside that folder, then
//  - warns when the same project is open on another device right now
//  - notices when another device changed a chapter or the binder, and loads it
//  - finds Dropbox "conflicted copies" and helps keep both versions
// Backups: automatic backups (now with images), restore any of them as a copy, full backup files (.unwip),
// and an optional extra copy to another folder or drive once a day.
window.UnwipSync = (function () {
  'use strict';
  const U = window.__unwip;
  const { $, $$, esc, fmt, S, api, editor } = U;
  let beat = null, current = null;

  // ================================================================== OPENING A PROJECT
  U.on('project', async p => {
    current = S.slug;
    api.presence(S.slug, true); clearInterval(beat);
    beat = setInterval(() => { if (S.slug) api.presence(S.slug, true); }, 60000);
    api.watchProject(S.slug);
    try {
      const others = await api.othersOpen(S.slug);
      if (others.length) {
        const o = others[0], mins = Math.max(1, Math.round((Date.now() - o.at) / 60000));
        U.modal({ title: 'Also open on another device', body: `<p><b>${esc(p.title)}</b> is open on <b>${esc(o.device)}</b> right now (active ${mins} minute${mins > 1 ? 's' : ''} ago).</p>
          <p>Writing on both at the same time can give Dropbox two versions of the same chapter. It’s safest to close it there first. Unwip will still pick up changes from the other device as they arrive.</p>`,
          buttons: [{ label: 'Got it', value: true, kind: 'primary' }] });
      }
    } catch {}
    checkConflicts();
  });
  U.on('leave', () => { if (current) { api.presence(current, false); api.watchProject(null); } clearInterval(beat); current = null; });
  window.addEventListener('beforeunload', () => { if (current) api.presence(current, false); });

  // ================================================================== CHANGES FROM ANOTHER DEVICE
  api.onExternalChange(async info => {
    if (!S.project || info.slug !== S.slug) return;
    if (info.file === 'project.json') {
      const load = async () => { clearTimeout(S.metaTimer); try { U.reloadProjectMeta(await api.openProject(S.slug)); U.toast('Updated with changes from your other device.'); } catch {} };
      if (S.metaTimer) U.toastAction('The binder was changed on another device.', 'Load those changes', load, 20000);
      else load();
      return;
    }
    if (info.id && info.id === S.docId) {
      const load = async () => {
        const html = await api.loadDoc(S.slug, info.id);
        const top = U.editorWrap.scrollTop;
        S.programmatic = true; editor.innerHTML = html || '<p><br></p>'; S.programmatic = false;
        S.dirty = false; U.resyncWords(); U.updateStatus(); U.editorWrap.scrollTop = top;
      };
      if (!S.dirty) { await load(); U.toast('This chapter was updated from your other device.'); }
      else U.toastAction('This chapter was also changed on another device.', 'Use that version', load, 20000);
    }
  });

  // ================================================================== DROPBOX CONFLICTED COPIES
  async function checkConflicts() {
    let list = []; try { list = await api.conflicts(S.slug); } catch { return; }
    if (!list.length) return;
    const titleOf = c => { if (c.kind !== 'doc') return 'The binder (project file)'; const id = c.original.replace(/\.html$/, ''); const f = U.findNode(id); return f ? f.node.title : 'A deleted document'; };
    const body = document.createElement('div');
    body.innerHTML = `<p>Dropbox found ${list.length === 1 ? 'a document that was' : 'documents that were'} changed on two devices at once, so it kept both versions. Nothing is lost. Choose what to do with each one.</p>
      <div class="sy-list">${list.map((c, i) => `<div class="sy-row" data-i="${i}"><div><b>${esc(titleOf(c))}</b><span>Other version from ${esc(c.device)}</span></div>
        <button class="btn small" data-a="keep">${c.kind === 'doc' ? 'Keep both' : 'Recover missing items'}</button><button class="btn small ghost" data-a="drop">Not needed</button></div>`).join('')}</div>
      <p class="rp-note">“Keep both” adds the other version as a new document right under the original, so you can compare them. “Not needed” moves it to the project’s backups folder rather than deleting it.</p>`;
    const handle = async (c, row, action) => {
      try {
        if (action === 'keep' && c.kind === 'doc') {
          const id = c.original.replace(/\.html$/, ''); const html = await api.readConflict(S.slug, c.file);
          const f = U.findNode(id);
          const node = { id: U.uid(), type: 'doc', title: `${f ? f.node.title : 'Recovered'} (version from ${c.device})`, words: U.countWords(html.replace(/<[^>]+>/g, ' ')) };
          if (f) f.list.splice(f.index + 1, 0, node); else U.findNode('root-manuscript').node.children.push(node);
          await api.saveDoc(S.slug, node.id, html);
        }
        if (action === 'keep' && c.kind === 'project') {
          const other = JSON.parse(await api.readConflict(S.slug, c.file)); const have = new Set(); U.walkTree(S.project.binder, n => { have.add(n.id); });
          const missing = []; U.walkTree(other.binder || [], n => { if (!have.has(n.id) && !n.root && n.type === 'doc') missing.push({ ...n, children: undefined }); });
          if (missing.length) {
            const notes = S.project.binder.find(n => n.root && n.kind === 'notes') || S.project.binder[0];
            notes.children.push({ id: U.uid(), type: 'folder', title: `Recovered from ${c.device}`, open: true, children: missing.map(m => ({ id: m.id, type: 'doc', title: m.title, synopsis: m.synopsis, words: m.words || 0 })) });
            notes.open = true;
          }
          U.toast(missing.length ? `Recovered ${missing.length} document${missing.length > 1 ? 's' : ''} into Notes › Recovered from ${esc(c.device)}.` : 'Nothing was missing. Your binder already has everything.');
        }
        await api.archiveConflict(S.slug, c.file);
        U.scheduleMeta(); U.renderBinder();
        row.classList.add('done'); row.querySelectorAll('button').forEach(b => b.disabled = true);
        row.querySelector('span').textContent = action === 'keep' ? 'Done' : 'Moved to backups';
      } catch (e) { U.toast('Couldn’t sort that one out: ' + esc(e.message || e), 'warn'); }
    };
    U.modal({ title: 'Two versions found', body, wide: true, buttons: [{ label: 'Close', value: true, kind: 'primary' }],
      onOpen: back => $$('.sy-row', back).forEach(row => row.querySelectorAll('[data-a]').forEach(b => b.onclick = () => handle(list[+row.dataset.i], row, b.dataset.a))) });
  }

  // ================================================================== SETTINGS: WHERE PROJECTS LIVE
  const ICON = { dropbox: '📦', onedrive: '☁️', default: '💻', custom: '📁' };
  async function settingsSection(body) {
    const box = $('#s-lib', body), extra = $('#s-extra', body);
    let info; try { info = await api.libraryInfo(); } catch { return; }
    const cur = info.places.find(p => p.kind === info.kind) || { label: 'A folder you chose', kind: 'custom' };
    const others = info.places.filter(p => p.kind !== info.kind);
    box.innerHTML = `<div class="sy-cur"><span class="sy-ic">${ICON[info.kind] || '📁'}</span><div><b>${esc(cur.label)}</b>${info.kind === 'dropbox' || info.kind === 'onedrive' ? ' <em class="sy-badge">syncing</em>' : ''}<span class="sy-path">${esc(info.path)}</span></div><button class="btn small ghost" id="sy-open" type="button">Open folder</button></div>
      ${info.kind === 'default' && !info.places.some(p => p.kind === 'dropbox') ? '<p class="sy-note">To sync between devices, install the Dropbox app on this PC, then come back here. Unwip will offer to move your projects into it.</p>' : ''}
      <div class="sy-moves">${others.map(p => `<button class="btn ${p.kind === 'dropbox' ? 'primary' : ''}" type="button" data-path="${esc(p.path)}" data-label="${esc(p.label)}" data-tip="${esc(p.path)}">${ICON[p.kind]} ${p.kind === 'default' ? 'Move back to this PC only' : `Sync with ${esc(p.label)}`}</button>`).join('')}
        <button class="btn ghost" type="button" id="sy-pick">Choose another folder…</button></div>`;
    $('#sy-open', box).onclick = () => api.revealProject(null);
    $$('[data-path]', box).forEach(b => b.onclick = () => move(b.dataset.path, b.dataset.label));
    $('#sy-pick', box).onclick = async () => { const p = await api.libraryPick(); if (p) move(p, 'that folder'); };
    const s = S.settings || {};
    const drawExtra = () => {
      const dir = (S.settings || {}).extraBackupDir;
      extra.innerHTML = `<label>Once a day, each project you work on is also saved as a full backup file (with images) in a second place, like a USB stick or another drive. The last 10 are kept.</label>
        <div class="sy-cur"><span class="sy-ic">${dir ? '🛟' : '—'}</span><div>${dir ? `<b>On</b><span class="sy-path">${esc(dir)}</span>` : '<b>Off</b>'}</div>
        <button class="btn small" id="sy-xpick" type="button">${dir ? 'Change…' : 'Choose a folder…'}</button>${dir ? '<button class="btn small ghost" id="sy-xoff" type="button">Turn off</button>' : ''}</div>`;
      $('#sy-xpick', extra).onclick = async () => { const p = await api.backupExtraPick(); if (p) { S.settings = await api.setSettings({ extraBackupDir: p }); drawExtra(); if (S.slug) api.backupExtraNow(S.slug); } };
      const off = $('#sy-xoff', extra); if (off) off.onclick = async () => { S.settings = await api.setSettings({ extraBackupDir: null }); drawExtra(); };
    };
    drawExtra();
  }
  async function move(target, label) {
    const ok = await U.confirmBox(`Move your projects to ${label}?`, `Unwip will copy every project (and your Play pieces) to:<br><b>${esc(target)}</b><br><br>If projects are already there from another device, both are kept. Your current folder isn’t deleted. It’s renamed “… (old copy)” so you can check everything arrived before removing it yourself.`, 'Move projects');
    if (!ok) return;
    const back = document.querySelector('.modal-back'); if (back) back.remove();
    if (S.slug) await U.showLibrary();
    U.toast('Moving your projects…', '', 2500);
    try {
      const r = await api.libraryMove(target);
      await U.showLibrary();
      U.modal({ title: 'Done', body: `<p>${r.moved ? `${r.moved} item${r.moved > 1 ? 's' : ''} copied` : 'Nothing needed copying'}${r.kept ? `, and ${r.kept} project${r.kept > 1 ? 's were' : ' was'} already there and up to date` : ''}.</p><p>Your projects now live in <b>${esc(r.path)}</b>.</p>${r.old && r.old !== r.path ? `<p class="rp-note">Your old folder is kept as <b>${esc(r.old)}</b>. Once you’ve checked everything opens fine, you can delete it.</p>` : ''}
        <p class="rp-note">On your other computer: install Unwip, then Settings → Where your projects live → Sync with Dropbox. It will find these projects.</p>`, buttons: [{ label: 'OK', value: true, kind: 'primary' }] });
    } catch (e) { U.toast('Couldn’t move the projects: ' + esc(e.message || e), 'warn', 8000); }
  }

  // ================================================================== BACKUPS DIALOG (from a project card)
  async function backupsDialog(slug, title) {
    const list = await api.backupList(slug);
    const when = st => { const d = new Date(st.slice(0, 10) + 'T' + st.slice(11, 19).replace(/-/g, ':') + 'Z'); return isNaN(d) ? st : d.toLocaleString(undefined, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); };
    const body = document.createElement('div');
    body.innerHTML = `<p>Unwip backs up <b>${esc(title)}</b> automatically when you open it, every 10 minutes while you write, and when you close it. The last 20 are kept, and images are backed up too.</p>
      ${list.length ? `<div class="sy-list">${list.map(b => `<div class="sy-row"><div><b>${esc(when(b.stamp))}</b><span>${b.docs} documents${b.words ? ` · ${fmt(b.words)} words in the manuscript` : ''}</span></div><button class="btn small" data-stamp="${esc(b.stamp)}">Restore as a copy</button></div>`).join('')}</div>` : '<p class="np-empty">No backups yet. One is made the next time you open the project.</p>'}
      <p class="rp-note">Restoring makes a separate project next to this one, so nothing current is overwritten. For a backup you can keep anywhere, use “Save a full backup file…” on the project’s menu.</p>`;
    U.modal({ title: 'Backups', body, wide: true, buttons: [{ label: 'Close', value: true, kind: 'primary' }],
      onOpen: back => $$('[data-stamp]', back).forEach(b => b.onclick = async () => {
        b.disabled = true;
        try { await api.backupRestore(slug, b.dataset.stamp); U.toast('Restored as a new project in your library.'); back.querySelector('.m-foot .btn').click(); U.showLibrary(); }
        catch (e) { U.toast('Couldn’t restore: ' + esc(e.message || e), 'warn'); b.disabled = false; }
      }) });
  }

  // a warning on the library screen if the sync folder has gone missing (e.g. Dropbox uninstalled)
  U.on('library', async () => {
    let info; try { info = await api.libraryInfo(); } catch { return; }
    let bar = $('#sy-warn');
    if (!info.parentMissing) { if (bar) bar.remove(); return; }
    if (!bar) { bar = document.createElement('div'); bar.id = 'sy-warn'; bar.className = 'sy-warn'; $('#write-home').prepend(bar); }
    bar.innerHTML = `Unwip can’t find the folder your projects sync to: <b>${esc(info.path)}</b>. Is Dropbox (or OneDrive) running on this PC? <button class="btn small" type="button">Settings</button>`;
    bar.querySelector('button').onclick = () => $('#btn-settings-lib').click();
  });

  return { settingsSection, backupsDialog, checkConflicts };
})();

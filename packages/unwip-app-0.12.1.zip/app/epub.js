// Unwip - EPUB writer (works for Kindle via Send to Kindle / KDP, Apple Books, Kobo, Google Play Books).
// Builds the EPUB 3 package (with an EPUB 2 table of contents for older readers) and zips it.
window.FolioEPUB = (function () {
  'use strict';

  // ---- tiny zip writer (files stored uncompressed, which EPUB allows) ----
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    return t;
  })();
  function crc32(bytes) { let c = 0xFFFFFFFF; for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zip(files) {   // files: [{name, data: Uint8Array}]
    const enc = new TextEncoder();
    const chunks = [], central = [];
    let offset = 0;
    const now = new Date();
    const dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    const dosDate = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    for (const f of files) {
      const name = enc.encode(f.name);
      const crc = crc32(f.data), size = f.data.length;
      const local = new DataView(new ArrayBuffer(30));
      local.setUint32(0, 0x04034b50, true); local.setUint16(4, 20, true); local.setUint16(6, 0x0800, true); local.setUint16(8, 0, true);
      local.setUint16(10, dosTime, true); local.setUint16(12, dosDate, true); local.setUint32(14, crc, true);
      local.setUint32(18, size, true); local.setUint32(22, size, true); local.setUint16(26, name.length, true); local.setUint16(28, 0, true);
      chunks.push(new Uint8Array(local.buffer), name, f.data);
      const cen = new DataView(new ArrayBuffer(46));
      cen.setUint32(0, 0x02014b50, true); cen.setUint16(4, 20, true); cen.setUint16(6, 20, true); cen.setUint16(8, 0x0800, true); cen.setUint16(10, 0, true);
      cen.setUint16(12, dosTime, true); cen.setUint16(14, dosDate, true); cen.setUint32(16, crc, true); cen.setUint32(20, size, true); cen.setUint32(24, size, true);
      cen.setUint16(28, name.length, true); cen.setUint16(30, 0, true); cen.setUint16(32, 0, true); cen.setUint16(34, 0, true); cen.setUint16(36, 0, true);
      cen.setUint32(38, 0, true); cen.setUint32(42, offset, true);
      central.push(new Uint8Array(cen.buffer), name);
      offset += 30 + name.length + size;
    }
    const cenSize = central.reduce((a, c) => a + c.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
    end.setUint32(12, cenSize, true); end.setUint32(16, offset, true);
    const all = [...chunks, ...central, new Uint8Array(end.buffer)];
    const out = new Uint8Array(all.reduce((a, c) => a + c.length, 0));
    let p = 0; for (const c of all) { out.set(c, p); p += c.length; }
    return out;
  }

  // ---- EPUB content ----
  const x = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const SCENE = /^\s*((\*|#|~|•|·)\s*){1,5}\s*$/;

  function runsXHTML(runs, notes) {
    return runs.map(r => {
      if (r.br) return '<br/>';
      if (r.fn !== undefined) { if (!notes) return ''; notes.push(r.fn); const k = notes.length; return `<a epub:type="noteref" class="noteref" href="#fn${k}" id="fnref${k}"><sup>${k}</sup></a>`; }
      let h = x(r.text);
      if (r.sup) h = `<sup>${h}</sup>`;
      if (r.sub) h = `<sub>${h}</sub>`;
      if (r.strike) h = `<s>${h}</s>`;
      if (r.underline) h = `<span class="u">${h}</span>`;
      if (r.italic) h = `<em>${h}</em>`;
      if (r.bold) h = `<strong>${h}</strong>`;
      return h;
    }).join('');
  }

  // split blocks into chapters at each Heading 1
  function chaptersOf(blocks, bookTitle) {
    const chapters = [];
    let cur = null;
    for (const b of blocks) {
      if (b.tag === 'h1') { cur = { title: b.runs.map(r => r.text || '').join('').trim() || 'Chapter', blocks: [b] }; chapters.push(cur); continue; }
      if (!cur) { cur = { title: bookTitle, blocks: [] }; chapters.push(cur); }
      cur.blocks.push(b);
    }
    return chapters.filter(c => c.blocks.some(b => b.runs.some(r => (r.text || '').trim())));
  }

  function chapterXHTML(ch, lang) {
    let body = '', afterBreak = true;
    const notes = [];
    for (const b of ch.blocks) {
      const text = b.runs.map(r => r.text || '').join('');
      if (!text.trim()) continue;                    // blank lines: e-readers handle spacing themselves
      if (/^h[1-3]$/.test(b.tag)) { body += `<${b.tag}>${runsXHTML(b.runs, notes)}</${b.tag}>\n`; afterBreak = true; continue; }
      if (SCENE.test(text)) { body += `<p class="scene">${x(text.trim())}</p>\n`; afterBreak = true; continue; }
      const cls = [afterBreak ? 'first' : '', b.align === 'center' ? 'center' : b.align === 'right' ? 'right' : '', b.tag === 'blockquote' ? 'quote' : ''].filter(Boolean).join(' ');
      body += `<p${cls ? ` class="${cls}"` : ''}>${runsXHTML(b.runs, notes)}</p>\n`;
      afterBreak = false;
    }
    return `<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="${lang}" lang="${lang}">
<head><meta charset="utf-8"/><title>${x(ch.title)}</title><link rel="stylesheet" type="text/css" href="style.css"/></head>
<body>
<section epub:type="chapter">
${body}</section>
${notes.length ? `<section class="notes"><hr/>\n${notes.map((t, i) => `<aside epub:type="footnote" id="fn${i + 1}"><p class="note"><a href="#fnref${i + 1}">${i + 1}.</a> ${x(t)}</p></aside>`).join('\n')}\n</section>` : ''}
</body>
</html>`;
  }

  function css(style) {
    const h1 = style.headings.h1;
    return `body { margin: 0 5%; font-family: "${style.font}", serif; line-height: 1.4; }
p { margin: 0; text-indent: 1.5em; text-align: ${style.justify ? 'justify' : 'left'}; }
p.first, p.center, p.right, p.scene { text-indent: 0; }
p.center { text-align: center; } p.right { text-align: right; }
p.quote { margin: 0 2em; text-indent: 0; }
p.scene { text-align: center; margin: 1em 0; }
h1 { font-family: "${h1.font}", serif; text-align: ${h1.align}; font-weight: ${h1.bold ? 'bold' : 'normal'}; font-style: ${h1.italic ? 'italic' : 'normal'}; font-size: 1.6em; margin: 3em 0 1.5em; page-break-before: always; }
h2 { font-size: 1.25em; margin: 1.5em 0 .6em; } h3 { font-size: 1.1em; margin: 1.2em 0 .5em; }
.u { text-decoration: underline; }
a.noteref { text-decoration: none; } a.noteref sup { font-size: .7em; line-height: 0; }
.notes hr { width: 30%; margin: 2em 0 1em; border: 0; border-top: 1px solid #999; text-align: left; } p.note { text-indent: 0; font-size: .85em; margin: 0 0 .4em; }
.title-page { text-align: center; margin-top: 30%; } .title-page h1 { page-break-before: auto; margin: 0 0 1em; } .title-page p { text-indent: 0; text-align: center; }`;
  }

  function uuid() {
    const b = crypto.getRandomValues(new Uint8Array(16)); b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
    const h = [...b].map(v => v.toString(16).padStart(2, '0')).join('');
    return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
  }

  function build({ blocks, style, title, author, lang, id }) {
    lang = (lang || 'en').split('-')[0];
    const chapters = chaptersOf(blocks, title);
    const enc = new TextEncoder();
    const files = [];
    const add = (name, text) => files.push({ name, data: enc.encode(text) });
    files.push({ name: 'mimetype', data: enc.encode('application/epub+zip') }); // must be first
    add('META-INF/container.xml', `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>`);
    add('OEBPS/style.css', css(style));
    add('OEBPS/title.xhtml', `<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="${lang}" lang="${lang}"><head><meta charset="utf-8"/><title>${x(title)}</title><link rel="stylesheet" type="text/css" href="style.css"/></head>
<body><div class="title-page"><h1>${x(title)}</h1>${author ? `<p>${x(author)}</p>` : ''}</div></body></html>`);
    chapters.forEach((c, i) => add(`OEBPS/ch${String(i + 1).padStart(3, '0')}.xhtml`, chapterXHTML(c, lang)));
    const items = chapters.map((c, i) => `ch${String(i + 1).padStart(3, '0')}`);
    add('OEBPS/nav.xhtml', `<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="${lang}" lang="${lang}"><head><meta charset="utf-8"/><title>Contents</title></head>
<body><nav epub:type="toc" id="toc"><h1>Contents</h1><ol>
${chapters.map((c, i) => `<li><a href="${items[i]}.xhtml">${x(c.title)}</a></li>`).join('\n')}
</ol></nav>
<nav epub:type="landmarks" hidden=""><ol><li><a epub:type="bodymatter" href="${items[0] || 'title'}.xhtml">Start</a></li></ol></nav></body></html>`);
    const ident = id || 'urn:uuid:' + uuid();
    add('OEBPS/toc.ncx', `<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="${x(ident)}"/></head>
<docTitle><text>${x(title)}</text></docTitle><navMap>
${chapters.map((c, i) => `<navPoint id="np${i + 1}" playOrder="${i + 1}"><navLabel><text>${x(c.title)}</text></navLabel><content src="${items[i]}.xhtml"/></navPoint>`).join('\n')}
</navMap></ncx>`);
    const modified = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
    add('OEBPS/content.opf', `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="${lang}">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="bookid">${x(ident)}</dc:identifier>
<dc:title>${x(title)}</dc:title>
${author ? `<dc:creator>${x(author)}</dc:creator>` : ''}
<dc:language>${lang}</dc:language>
<meta property="dcterms:modified">${modified}</meta>
</metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
<item id="css" href="style.css" media-type="text/css"/>
<item id="title" href="title.xhtml" media-type="application/xhtml+xml"/>
${items.map(i => `<item id="${i}" href="${i}.xhtml" media-type="application/xhtml+xml"/>`).join('\n')}
</manifest>
<spine toc="ncx">
<itemref idref="title"/>
${items.map(i => `<itemref idref="${i}"/>`).join('\n')}
</spine>
</package>`);
    return { bytes: zip(files), chapters: chapters.length };
  }

  return { build, zip };
})();

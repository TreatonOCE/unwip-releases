// Unwip - Import a Scrivener project straight from Dropbox (iPhone / iPad / web version).
// A phone can't pick a .scriv folder in the Files app, so Unwip asks Dropbox for it directly. This uses its own,
// separate Dropbox permission that can only READ (it's asked for the first time you import, and is never used for
// syncing). The project is fetched as one download and read here; nothing in Dropbox is changed.
window.UnwipDropboxImport = (function () {
  'use strict';
  const F = window.folio;
  if (!F || !F.web || !F.__fs) return null;
  const KEY = window.UNWIP_DROPBOX_IMPORT_KEY || '';
  const FS = F.__fs, STATE = 'app/dropbox-import.json';
  const API = 'https://api.dropboxapi.com/2', CONTENT = 'https://content.dropboxapi.com/2';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const b64url = a => btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const headerJSON = o => JSON.stringify(o).replace(/[\u007f-￿]/g, c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
  const standalone = () => !!(navigator.standalone || (window.matchMedia && matchMedia('(display-mode: standalone)').matches));
  const redirectUri = () => location.origin + location.pathname.replace(/index\.html$/, '');
  // back from Dropbox's sign-in page (read now, before anything tidies the address)
  const back = new URLSearchParams(location.search);
  let st = null;
  const load = async () => { if (!st) st = await FS.json(STATE, {}); return st; };
  const save = () => FS.write(STATE, JSON.stringify(st));
  const ready = () => !!KEY;

  async function token() {
    await load();
    if (st.access && st.exp > Date.now() + 60000) return st.access;
    if (!st.refresh) return null;
    const r = await fetch('https://api.dropboxapi.com/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: st.refresh, client_id: KEY }) });
    if (!r.ok) { st = {}; await save(); return null; }
    const j = await r.json(); st.access = j.access_token; st.exp = Date.now() + (j.expires_in || 14400) * 1000; await save();
    return st.access;
  }
  async function call(url, opts) {
    const t = await token(); if (!t) throw new Error('NEEDS_SIGN_IN');
    for (let attempt = 0; ; attempt++) {
      const r = await fetch(url, { ...opts, headers: { ...(opts.headers || {}), Authorization: 'Bearer ' + t } });
      if ((r.status === 429 || r.status >= 500) && attempt < 5) { await new Promise(res => setTimeout(res, 1000 * 2 ** attempt)); continue; }
      return r;
    }
  }
  const rpc = (p, body) => call(API + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

  // ---- signing in (once): read-only access to Dropbox
  async function signIn(after) {
    const U = window.__unwip;
    const v = b64url(crypto.getRandomValues(new Uint8Array(48)));
    const c = b64url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(v))));
    const state = 'imp_' + b64url(crypto.getRandomValues(new Uint8Array(12)));
    const q = { client_id: KEY, response_type: 'code', code_challenge: c, code_challenge_method: 'S256', token_access_type: 'offline' };
    const intro = `<p>To bring in a Scrivener project, Unwip needs to <b>read</b> it from your Dropbox. This is a separate, read-only permission: it can look at your Dropbox and download a project, but can’t change or delete anything. It’s only used when you import.</p>`;
    if (standalone()) {
      const url = 'https://www.dropbox.com/oauth2/authorize?' + new URLSearchParams(q);
      const body = document.createElement('div');
      body.innerHTML = intro + `<ol class="dbx-steps"><li>Tap <b>Open Dropbox</b>. Sign in and tap <b>Allow</b>.</li><li>Dropbox shows a code. Copy it.</li><li>Come back here and paste it below.</li></ol>
        <p><a class="btn primary dbx-open" href="${url}" target="_blank" rel="noopener">Open Dropbox</a></p>
        <div class="field"><input type="text" id="dbi-code" placeholder="Paste the code from Dropbox" autocomplete="off" autocapitalize="off" spellcheck="false"></div>`;
      const ok = await U.modal({ title: 'Read your Dropbox', body, buttons: [{ label: 'Cancel', value: false, kind: 'ghost' }, { label: 'Continue', value: true, kind: 'primary' }] });
      const code = ok && body.querySelector('#dbi-code').value.trim();
      return code ? finish(code, v, null) : false;
    }
    const go = await U.modal({ title: 'Read your Dropbox', body: intro + '<p>Dropbox will ask you to allow it, then bring you straight back here.</p>', buttons: [{ label: 'Cancel', value: false, kind: 'ghost' }, { label: 'Continue to Dropbox', value: true, kind: 'primary' }] });
    if (!go) return false;
    sessionStorage.setItem('unwip-dbx-imp', JSON.stringify({ v, state, after: after || '' }));
    location.href = 'https://www.dropbox.com/oauth2/authorize?' + new URLSearchParams({ ...q, redirect_uri: redirectUri(), state });
    return false;
  }
  async function finish(code, verifier, redirect) {
    const body = { code, grant_type: 'authorization_code', client_id: KEY, code_verifier: verifier };
    if (redirect) body.redirect_uri = redirect;
    const r = await fetch('https://api.dropboxapi.com/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(body) });
    if (!r.ok) { window.__unwip.toast('Dropbox didn’t accept that. Try again (the code only works once, for a few minutes).', 'warn', 9000); return false; }
    const j = await r.json(); await load();
    Object.assign(st, { access: j.access_token, refresh: j.refresh_token, exp: Date.now() + (j.expires_in || 14400) * 1000 });
    await save(); return true;
  }

  // ---- choosing the project: a small Dropbox browser, Scrivener projects marked
  async function list(path) {
    let r = await rpc('/files/list_folder', { path, recursive: false, include_deleted: false, limit: 2000 });
    if (r.status === 401) { st = {}; await save(); throw new Error('NEEDS_SIGN_IN'); }
    if (!r.ok) throw new Error('Dropbox couldn’t list that folder (' + r.status + ').');
    let j = await r.json(); const out = [...j.entries];
    while (j.has_more) { r = await rpc('/files/list_folder/continue', { cursor: j.cursor }); if (!r.ok) break; j = await r.json(); out.push(...j.entries); }
    return out;
  }
  async function exists(path) { const r = await rpc('/files/get_metadata', { path }); return r.ok; }
  async function browse() {
    const U = window.__unwip;
    let path = (await exists('/Apps/Scrivener')) ? '/Apps/Scrivener' : '';
    const body = document.createElement('div'); body.className = 'dbi';
    let resolveDone; const done = new Promise(r => { resolveDone = r; });
    const draw = async () => {
      body.innerHTML = '<p class="hint">Looking in Dropbox…</p>';
      let items;
      try { items = await list(path); } catch (e) { body.innerHTML = `<p class="hint">${esc(e.message === 'NEEDS_SIGN_IN' ? 'Dropbox needs you to sign in again.' : e.message)}</p>`; return; }
      const folders = items.filter(e => e['.tag'] === 'folder').sort((a, b) => a.name.localeCompare(b.name));
      const projects = folders.filter(f => /\.scriv$/i.test(f.name)), others = folders.filter(f => !/\.scriv$/i.test(f.name));
      const crumbs = path.split('/').filter(Boolean);
      body.innerHTML = `<div class="dbi-path"><button class="link-btn" data-go="">Dropbox</button>${crumbs.map((c, i) => ` › <button class="link-btn" data-go="/${esc(crumbs.slice(0, i + 1).join('/'))}">${esc(c)}</button>`).join('')}</div>
        ${projects.length ? `<div class="dbi-h">Scrivener projects</div><div class="dbi-list">${projects.map(f => `<button class="dbi-row dbi-proj" data-pick="${esc(f.path_lower)}" data-name="${esc(f.name)}"><span class="dbi-ic">📘</span><span>${esc(f.name.replace(/\.scriv$/i, ''))}</span><span class="dbi-go">Import</span></button>`).join('')}</div>` : ''}
        ${others.length ? `<div class="dbi-h">Folders</div><div class="dbi-list">${others.map(f => `<button class="dbi-row" data-go="${esc(f.path_display)}"><span class="dbi-ic">📁</span><span>${esc(f.name)}</span><span class="dbi-go">›</span></button>`).join('')}</div>` : ''}
        ${!projects.length && !others.length ? '<p class="hint">No folders or Scrivener projects here.</p>' : ''}`;
      body.querySelectorAll('[data-go]').forEach(b => b.onclick = () => { path = b.dataset.go; draw(); });
      body.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => resolveDone({ path: b.dataset.pick, name: b.dataset.name }));
    };
    const m = U.modal({ title: 'Import from Dropbox', body, wide: true, buttons: [{ label: 'Cancel', value: false, kind: 'ghost' }] }).then(() => resolveDone(null));
    draw();
    const pick = await done;
    document.querySelectorAll('.modal-back').forEach(mb => { if (mb.contains(body)) { const b = mb.querySelector('.m-foot .btn'); if (b) b.click(); } });
    await m;
    return pick;
  }
  // the whole project in one download (Dropbox zips the folder), read the same way as everywhere else
  async function fetchProject(pick) {
    const U = window.__unwip;
    U.toast(`Fetching “${esc(pick.name.replace(/\.scriv$/i, ''))}” from Dropbox…`, '', 4000);
    const r = await call(CONTENT + '/files/download_zip', { method: 'POST', headers: { 'Dropbox-API-Arg': headerJSON({ path: pick.path }) } });
    if (!r.ok) throw new Error(r.status === 409 ? 'Dropbox couldn’t pack that project (it may be too big, or still syncing). Try again in a minute.' : 'Dropbox download failed (' + r.status + ').');
    return F.__readScrivZip(new Uint8Array(await r.arrayBuffer()), pick.name);
  }
  // the import's first step: returns the project's files, or null
  async function pickProject() {
    await load();
    if (!(await token())) { if (!(await signIn('scriv'))) return null; }
    try { const pick = await browse(); return pick ? await fetchProject(pick) : null; }
    catch (e) { if (e.message === 'NEEDS_SIGN_IN') { if (await signIn('scriv')) return pickProject(); return null; } throw e; }
  }
  async function forget() { await load(); try { await rpc('/auth/token/revoke', null); } catch {} st = {}; await save(); }

  // came back from Dropbox's sign-in: finish, then carry on with the import
  (async () => {
    if (!back.get('code') || !/^imp_/.test(back.get('state') || '')) return;
    const saved = JSON.parse(sessionStorage.getItem('unwip-dbx-imp') || 'null'); sessionStorage.removeItem('unwip-dbx-imp');
    history.replaceState(null, '', location.pathname);
    if (!saved || saved.state !== back.get('state')) return;
    const ok = await finish(back.get('code'), saved.v, redirectUri());
    if (ok && saved.after === 'scriv') setTimeout(() => window.UnwipScriv && window.UnwipScriv.start({ fromDropbox: true }), 1500);
  })();

  return { ready, pickProject, forget };
})();

// Unwip - short quotes from writers, to keep going. Kept to well-sourced lines.
window.UnwipQuotes = (function () {
  const Q = [
    ['The first draft is just you telling yourself the story.', 'Terry Pratchett'],
    ['You can always edit a bad page. You can’t edit a blank page.', 'Jodi Picoult'],
    ['If there’s a book that you want to read, but it hasn’t been written yet, then you must write it.', 'Toni Morrison'],
    ['First, forget inspiration. Habit is more dependable.', 'Octavia E. Butler'],
    ['You don’t start out writing good stuff. You start out writing crap and thinking it’s good stuff, and then gradually you get better at it.', 'Octavia E. Butler'],
    ['Amateurs sit and wait for inspiration, the rest of us just get up and go to work.', 'Stephen King'],
    ['The scariest moment is always just before you start.', 'Stephen King'],
    ['If you want to be a writer, you must do two things above all others: read a lot and write a lot.', 'Stephen King'],
    ['The road to hell is paved with adverbs.', 'Stephen King'],
    ['This is how you do it: you sit down at the keyboard and you put one word after another until it’s done.', 'Neil Gaiman'],
    ['Tomorrow may be hell, but today was a good writing day, and on the good writing days nothing else matters.', 'Neil Gaiman'],
    ['There is no greater agony than bearing an untold story inside you.', 'Maya Angelou'],
    ['You can’t use up creativity. The more you use, the more you have.', 'Maya Angelou'],
    ['Start writing, no matter what. The water does not flow until the faucet is turned on.', 'Louis L’Amour'],
    ['A professional writer is an amateur who didn’t quit.', 'Richard Bach'],
    ['I love deadlines. I love the whooshing noise they make as they go by.', 'Douglas Adams'],
    ['Writing is like driving at night in the fog. You can only see as far as your headlights, but you can make the whole trip that way.', 'E. L. Doctorow'],
    ['Just write every day of your life. Read intensely. Then see what happens.', 'Ray Bradbury'],
    ['You fail only if you stop writing.', 'Ray Bradbury'],
    ['We write to taste life twice, in the moment and in retrospect.', 'Anaïs Nin'],
    ['Write what should not be forgotten.', 'Isabel Allende'],
    ['Fill your paper with the breathings of your heart.', 'William Wordsworth'],
    ['Either write something worth reading or do something worth writing.', 'Benjamin Franklin'],
    ['One day I will find the right words, and they will be simple.', 'Jack Kerouac'],
    ['Don’t get it right, just get it written.', 'James Thurber'],
    ['Ideas are like rabbits. You get a couple and learn how to handle them, and pretty soon you have a dozen.', 'John Steinbeck'],
    ['A word after a word after a word is power.', 'Margaret Atwood'],
    ['Write. Rewrite. When not writing or rewriting, read. I know of no shortcuts.', 'Larry L. King']
  ];
  const pick = (seed) => Q[Math.abs(seed) % Q.length];
  function today() { const d = new Date(); return pick(d.getFullYear() * 400 + d.getMonth() * 32 + d.getDate()); }
  function random(not) { let q; do q = Q[Math.floor(Math.random() * Q.length)]; while (Q.length > 1 && q === not); return q; }
  return { all: Q, today, random };
})();

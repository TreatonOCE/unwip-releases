// Unwip - main process: windows, files, clipboard, fonts, backups, PDF export.
const { app, BrowserWindow, ipcMain, clipboard, dialog, shell, session, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

// Projects live in Documents\Unwip. Earlier versions (named Folio) used Documents\Folio, so move that across once.
let libraryPath = null;
// The library can also live in a synced folder (Dropbox, OneDrive…), chosen in Settings. That choice is kept in settings.json.
let libraryOverride = undefined;
const LIBRARY = () => {
  if (libraryOverride === undefined) { try { const s = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'settings.json'), 'utf8')); libraryOverride = s.libraryPath || null; } catch { libraryOverride = null; } }
  return libraryOverride || libraryPath || path.join(app.getPath('documents'), 'Unwip');
};
const DEFAULT_LIBRARY = () => libraryPath || path.join(app.getPath('documents'), 'Unwip');
const FONT_DIR = () => path.join(app.getPath('userData'), 'fonts');
const MAX_BACKUPS = 20;
const OFFSCREEN = process.env.FOLIO_OFFSCREEN === '1'; // only used by automated tests

// One-time move from the old name. If a folder is in use and can't be renamed, keep using the old one.
(function migrateFromFolio() {
  if (OFFSCREEN) return;
  try {
    const docs = app.getPath('documents');
    const oldLib = path.join(docs, 'Folio'), newLib = path.join(docs, 'Unwip');
    if (fs.existsSync(oldLib) && !fs.existsSync(newLib)) {
      try { fs.renameSync(oldLib, newLib); } catch { libraryPath = oldLib; }
    }
    const appData = app.getPath('appData');
    const oldUD = path.join(appData, 'Folio'), newUD = path.join(appData, 'Unwip');
    if (fs.existsSync(oldUD) && !fs.existsSync(newUD)) {
      try { fs.renameSync(oldUD, newUD); app.setPath('userData', newUD); } catch { app.setPath('userData', oldUD); }
    } else app.setPath('userData', newUD);
  } catch {}
})();

let win;

function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); return p; }
function readJSON(p, fallback) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; } }
// remembers a fingerprint of every file Unwip writes, so changes made by another device (via Dropbox) can be told apart
const written = new Map();
const fingerprint = data => require('crypto').createHash('sha1').update(data).digest('hex');
function writeFileSafe(p, data) {
  // write to a temp file then rename, so a crash mid-save never corrupts the original
  const tmp = p + '.tmp';
  written.set(path.resolve(p), fingerprint(data));
  fs.writeFileSync(tmp, data);
  fs.renameSync(tmp, p);
}
function slugify(name) {
  return (name || 'Untitled').replace(/[<>:"/\\|?*\x00-\x1F]/g, '').trim().slice(0, 60) || 'Untitled';
}
function projectDir(slug) {
  const dir = path.resolve(LIBRARY(), slug);
  if (!dir.startsWith(path.resolve(LIBRARY()))) throw new Error('Bad project path');
  return dir;
}
function safeId(id) { return String(id).replace(/[^a-zA-Z0-9_-]/g, ''); }

function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600,
    backgroundColor: '#f7f5f0',
    title: 'Unwip',
    icon: path.join(__dirname, 'app', process.platform === 'win32' ? 'icon.ico' : 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true,
      offscreen: OFFSCREEN
    }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'app', 'index.html'));

  // Spellcheck suggestions on right-click inside the editor
  // Right-click menu in text areas: spelling, cut/copy/paste, and a clipboard check for troubleshooting
  win.webContents.on('context-menu', (_e, params) => {
    if (!params.isEditable) return;
    const items = [];
    if (params.misspelledWord) {
      for (const s of params.dictionarySuggestions.slice(0, 6)) items.push({ label: s, click: () => win.webContents.replaceMisspelling(s) });
      if (!items.length) items.push({ label: 'No suggestions', enabled: false });
      items.push({ label: `Add "${params.misspelledWord}" to dictionary`, click: () => win.webContents.session.addWordToSpellCheckerDictionary(params.misspelledWord) });
      items.push({ type: 'separator' });
    }
    items.push({ label: 'Cut', role: 'cut', enabled: params.editFlags.canCut });
    items.push({ label: 'Copy', role: 'copy', enabled: params.editFlags.canCopy });
    items.push({ label: 'Paste', role: 'paste', enabled: params.editFlags.canPaste });
    items.push({ label: 'Paste matching manuscript style', enabled: params.editFlags.canPaste, click: () => win.webContents.send('paste-plain') });
    items.push({ type: 'separator' });
    items.push({ label: 'Add comment   (Ctrl+Alt+M)', click: () => win.webContents.send('note-cmd', 'comment') });
    items.push({ label: 'Insert footnote   (Ctrl+Alt+F)', click: () => win.webContents.send('note-cmd', 'footnote') });
    items.push({ type: 'separator' });
    items.push({ label: 'Split document here   (Ctrl+K)', click: () => win.webContents.send('split-here') });
    items.push({ type: 'separator' });
    items.push({ label: 'Clipboard check (troubleshooting)…', click: clipboardCheck });
    Menu.buildFromTemplate(items).popup();
  });

  win.webContents.on('found-in-page', (_e, result) => win.webContents.send('find-result', result));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

if (process.platform === 'win32') app.setAppUserModelId('Unwip.Writing');
app.whenReady().then(() => {
  // allow the editor to list fonts installed on this PC
  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'local-fonts'));
  session.defaultSession.setPermissionCheckHandler((_wc, perm) => perm === 'local-fonts');
  applySpellSettings();
  ensureDir(LIBRARY());
  ensureDir(FONT_DIR());
  createWindow();
});
app.on('window-all-closed', () => app.quit());

// ---------- Projects ----------
ipcMain.handle('projects:list', () => {
  ensureDir(LIBRARY());
  return fs.readdirSync(LIBRARY(), { withFileTypes: true })
    .filter(d => d.isDirectory() && fs.existsSync(path.join(LIBRARY(), d.name, 'project.json')))
    .map(d => {
      const p = readJSON(path.join(LIBRARY(), d.name, 'project.json'), {});
      // the few documents changed most recently, for "Recently updated" on the main screen
      const recent = []; (function walk(l) { for (const n of l || []) { if (n.type === 'doc' && n.mod && !n.map) recent.push({ id: n.id, title: n.title, mod: n.mod, dev: n.dev || '' }); if (n.children) walk(n.children); } })(p.binder);
      recent.sort((a, b) => b.mod - a.mod);
      return { slug: d.name, title: p.title || d.name, words: p.totalWords || 0, modified: p.modified || 0, dev: p.lastDevice || '', recent: recent.slice(0, 3), days: (p.statsVersion === 2 && p.stats && p.stats.days) || {}, goals: p.goals || {} };
    })
    .sort((a, b) => b.modified - a.modified);
});

ipcMain.handle('projects:create', (_e, title, template) => {
  let base = slugify(title), slug = base, n = 2;
  while (fs.existsSync(path.join(LIBRARY(), slug))) slug = `${base} (${n++})`;
  const dir = ensureDir(projectDir(slug));
  ensureDir(path.join(dir, 'docs'));
  const project = { ...template, title, created: Date.now(), modified: Date.now() };
  writeFileSafe(path.join(dir, 'project.json'), JSON.stringify(project, null, 2));
  return slug;
});

ipcMain.handle('projects:open', (_e, slug) => {
  const dir = projectDir(slug);
  const project = readJSON(path.join(dir, 'project.json'), null);
  if (!project) throw new Error('Could not open project');
  return project;
});

ipcMain.handle('projects:saveMeta', (_e, slug, project) => {
  const dir = projectDir(slug);
  project.modified = Date.now();
  writeFileSafe(path.join(dir, 'project.json'), JSON.stringify(project, null, 2));
  return true;
});

ipcMain.handle('projects:delete', async (_e, slug) => {
  const dir = projectDir(slug);
  await shell.trashItem(dir); // goes to the Windows Recycle Bin, never permanently deleted
  return true;
});

ipcMain.handle('projects:reveal', (_e, slug) => shell.openPath(slug ? projectDir(slug) : LIBRARY()));

// ---------- Documents ----------
// ---------- Play (practice writing, kept apart from projects in Documents\Unwip\_Play) ----------
const PLAY_DIR = () => path.join(LIBRARY(), '_Play');
ipcMain.handle('play:load', () => readJSON(path.join(PLAY_DIR(), 'play.json'), { pieces: [], days: {} }));
ipcMain.handle('play:save', (_e, index) => { ensureDir(PLAY_DIR()); writeFileSafe(path.join(PLAY_DIR(), 'play.json'), JSON.stringify(index, null, 2)); return true; });
ipcMain.handle('play:loadPiece', (_e, id) => { try { return fs.readFileSync(path.join(PLAY_DIR(), 'pieces', safeId(id) + '.html'), 'utf8'); } catch { return ''; } });
ipcMain.handle('play:savePiece', (_e, id, html) => { const d = ensureDir(path.join(PLAY_DIR(), 'pieces')); writeFileSafe(path.join(d, safeId(id) + '.html'), html); return true; });
ipcMain.handle('play:deletePiece', (_e, id) => { try { fs.unlinkSync(path.join(PLAY_DIR(), 'pieces', safeId(id) + '.html')); } catch {} return true; });

ipcMain.handle('docs:load', (_e, slug, id) => {
  const p = path.join(projectDir(slug), 'docs', safeId(id) + '.html');
  try { return fs.readFileSync(p, 'utf8'); } catch { return ''; }
});
ipcMain.handle('docs:save', (_e, slug, id, html) => {
  const dir = ensureDir(path.join(projectDir(slug), 'docs'));
  writeFileSafe(path.join(dir, safeId(id) + '.html'), html);
  return true;
});

// ---------- Snapshots (saved versions of a single document) ----------
const snapDir = (slug, id) => path.join(projectDir(slug), 'snapshots', safeId(id));
ipcMain.handle('snap:save', (_e, slug, id, html, label, auto) => {
  const dir = ensureDir(snapDir(slug, id));
  const ts = Date.now();
  writeFileSafe(path.join(dir, ts + '.html'), html);
  const metaFile = path.join(dir, 'snapshots.json');
  const meta = readJSON(metaFile, []);
  meta.push({ ts, label: label || '', auto: !!auto });
  // keep at most 40 automatic snapshots per document (named ones are never removed)
  const autos = meta.filter(m => m.auto);
  while (autos.length > 40) { const old = autos.shift(); meta.splice(meta.indexOf(old), 1); fs.rmSync(path.join(dir, old.ts + '.html'), { force: true }); }
  writeFileSafe(metaFile, JSON.stringify(meta, null, 2));
  return ts;
});
ipcMain.handle('snap:list', (_e, slug, id) => readJSON(path.join(snapDir(slug, id), 'snapshots.json'), []).sort((a, b) => b.ts - a.ts));
ipcMain.handle('snap:load', (_e, slug, id, ts) => { try { return fs.readFileSync(path.join(snapDir(slug, id), Number(ts) + '.html'), 'utf8'); } catch { return null; } });
ipcMain.handle('snap:delete', (_e, slug, id, ts) => {
  const dir = snapDir(slug, id), metaFile = path.join(dir, 'snapshots.json');
  const meta = readJSON(metaFile, []).filter(m => m.ts !== Number(ts));
  writeFileSafe(metaFile, JSON.stringify(meta, null, 2));
  fs.rmSync(path.join(dir, Number(ts) + '.html'), { force: true });
  return true;
});
ipcMain.handle('snap:rename', (_e, slug, id, ts, label) => {
  const metaFile = path.join(snapDir(slug, id), 'snapshots.json');
  const meta = readJSON(metaFile, []); const m = meta.find(x => x.ts === Number(ts)); if (m) { m.label = label; m.auto = false; }
  writeFileSafe(metaFile, JSON.stringify(meta, null, 2)); return true;
});

// ---------- Media (moodboard images), stored inside the project ----------
const mediaDir = slug => ensureDir(path.join(projectDir(slug), 'media'));
const IMG_EXT = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'avif'];
function storeMedia(slug, bytes, ext) {
  ext = String(ext || 'png').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!IMG_EXT.includes(ext)) ext = 'png';
  const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  fs.writeFileSync(path.join(mediaDir(slug), id + '.' + ext), Buffer.from(bytes));
  return id + '.' + ext;
}
ipcMain.handle('media:pick', async (_e, slug) => {
  const res = await dialog.showOpenDialog(win, { title: 'Add images', properties: ['openFile', 'multiSelections'], filters: [{ name: 'Images', extensions: IMG_EXT }] });
  if (res.canceled) return [];
  return res.filePaths.map(f => ({ file: storeMedia(slug, fs.readFileSync(f), path.extname(f).slice(1)), name: path.basename(f) }));
});
ipcMain.handle('media:add', (_e, slug, bytes, ext) => storeMedia(slug, bytes, ext));
// pictures placed inside a chapter: the screen shrinks and embeds them, so just hand over the file
ipcMain.handle('image:pick', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Insert a picture', properties: ['openFile'], filters: [{ name: 'Images', extensions: IMG_EXT }] });
  if (res.canceled || !res.filePaths.length) return null;
  const f = res.filePaths[0]; const ext = path.extname(f).slice(1).toLowerCase();
  return { name: path.basename(f), type: 'image/' + (ext === 'jpg' ? 'jpeg' : ext), bytes: fs.readFileSync(f) };
});
ipcMain.handle('media:get', (_e, slug, file) => {
  const f = path.join(mediaDir(slug), path.basename(String(file)));
  try {
    const ext = path.extname(f).slice(1).toLowerCase();
    const mime = ext === 'jpg' ? 'jpeg' : ext;
    return `data:image/${mime};base64,` + fs.readFileSync(f).toString('base64');
  } catch { return null; }
});

// ---------- Import ----------
// pictures in a Scrivener project come back as data: addresses (the screen shrinks big ones)
function picFile(f) { try { const ext = path.extname(f).slice(1).toLowerCase(); return `data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,` + fs.readFileSync(f).toString('base64'); } catch { return null; } }
// Scrivener: returns the binder file and every document's text, synopsis and notes
ipcMain.handle('import:scrivener', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Choose a Scrivener project (.scriv folder, or the .scrivx file inside it)',
    properties: ['openDirectory', 'openFile'],
    filters: [{ name: 'Scrivener project', extensions: ['scrivx', 'scriv'] }]
  });
  if (res.canceled || !res.filePaths.length) return null;
  let p = res.filePaths[0];
  let scrivDir = p, scrivx = null;
  if (p.toLowerCase().endsWith('.scrivx')) { scrivx = p; scrivDir = path.dirname(p); }
  else {
    const found = fs.readdirSync(p).find(f => f.toLowerCase().endsWith('.scrivx'));
    if (!found) throw new Error('That folder is not a Scrivener project (no .scrivx file inside).');
    scrivx = path.join(p, found);
  }
  const files = {};
  const read = (f) => { try { return fs.readFileSync(f, 'utf8'); } catch { return null; } };
  const dataDir = path.join(scrivDir, 'Files', 'Data');            // Scrivener 3
  if (fs.existsSync(dataDir)) {
    for (const uuid of fs.readdirSync(dataDir)) {
      const d = path.join(dataDir, uuid);
      if (!fs.statSync(d).isDirectory()) continue;
      files[uuid] = { content: read(path.join(d, 'content.rtf')), synopsis: read(path.join(d, 'synopsis.txt')), notes: read(path.join(d, 'notes.rtf')) };
      const pic = fs.readdirSync(d).find(f => /^content\.(png|jpe?g|gif|webp)$/i.test(f));
      if (pic) files[uuid].image = picFile(path.join(d, pic));
    }
  }
  const docsDir = path.join(scrivDir, 'Files', 'Docs');            // Scrivener 1 & 2
  if (fs.existsSync(docsDir)) {
    for (const f of fs.readdirSync(docsDir)) {
      const pm = f.match(/^(\d+)\.(png|jpe?g|gif|webp)$/i);
      if (pm) { (files[pm[1]] = files[pm[1]] || {}).image = picFile(path.join(docsDir, f)); continue; }
      const m = f.match(/^(\d+)(_synopsis\.txt|_notes\.rtf|\.rtf)$/i); if (!m) continue;
      const e = files[m[1]] = files[m[1]] || {};
      const key = /synopsis/i.test(m[2]) ? 'synopsis' : /notes/i.test(m[2]) ? 'notes' : 'content';
      e[key] = read(path.join(docsDir, f));
    }
  }
  return { name: path.basename(scrivDir).replace(/\.scriv$/i, ''), scrivx: read(scrivx), files };
});
ipcMain.handle('import:docx', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Import a Word document', properties: ['openFile'], filters: [{ name: 'Word document', extensions: ['docx'] }] });
  if (res.canceled || !res.filePaths.length) return null;
  const f = res.filePaths[0];
  return { name: path.basename(f).replace(/\.docx$/i, ''), bytes: fs.readFileSync(f) };
});

// Books from other programs: Word, LibreOffice, RTF, plain text, Markdown, web pages - one file, several, or a whole folder
const BOOK_EXT = ['docx', 'odt', 'rtf', 'txt', 'md', 'markdown', 'text', 'htm', 'html'];
const bookFile = f => ({ name: path.basename(f).replace(/\.[^.]+$/, ''), ext: path.extname(f).slice(1).toLowerCase(), bytes: fs.readFileSync(f) });
ipcMain.handle('import:files', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Choose your book (pick several files to bring in several chapters)', properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Writing (Word, Google Docs download, LibreOffice, RTF, text, Markdown)', extensions: BOOK_EXT }, { name: 'All files', extensions: ['*'] }] });
  if (res.canceled || !res.filePaths.length) return null;
  return res.filePaths.map(bookFile);
});
ipcMain.handle('import:folder', async () => {
  const res = await dialog.showOpenDialog(win, { title: 'Choose the folder that holds your chapter files', properties: ['openDirectory'] });
  if (res.canceled || !res.filePaths.length) return null;
  const dir = res.filePaths[0];
  const files = fs.readdirSync(dir).filter(f => !/^[~.]/.test(f) && BOOK_EXT.includes(path.extname(f).slice(1).toLowerCase()))
    .map(f => path.join(dir, f)).filter(f => { try { return fs.statSync(f).isFile(); } catch { return false; } });
  return { folder: path.basename(dir), files: files.map(bookFile) };
});

// ---------- Backups ----------
ipcMain.handle('backup:make', (_e, slug) => {
  const dir = projectDir(slug);
  const bdir = ensureDir(path.join(dir, 'backups'));
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const target = path.join(bdir, stamp);
  ensureDir(path.join(target, 'docs'));
  fs.copyFileSync(path.join(dir, 'project.json'), path.join(target, 'project.json'));
  for (const f of fs.readdirSync(path.join(dir, 'docs'))) {
    if (f.endsWith('.html')) fs.copyFileSync(path.join(dir, 'docs', f), path.join(target, 'docs', f));
  }
  // images (moodboard etc.) never change once added, so they're kept once in backups/media rather than in every backup
  const mdir = path.join(dir, 'media');
  if (fs.existsSync(mdir)) {
    const bm = ensureDir(path.join(bdir, 'media'));
    for (const f of fs.readdirSync(mdir)) if (!fs.existsSync(path.join(bm, f))) fs.copyFileSync(path.join(mdir, f), path.join(bm, f));
  }
  extraBackup(slug, false);
  const all = fs.readdirSync(bdir).filter(f => /^\d{4}-/.test(f)).sort();
  while (all.length > MAX_BACKUPS) fs.rmSync(path.join(bdir, all.shift()), { recursive: true, force: true });
  return stamp;
});

// ---------- Clipboard ----------
ipcMain.handle('clipboard:write', (_e, html, text) => { clipboard.write({ html, text }); return true; });
ipcMain.handle('clipboard:read', () => ({ html: clipboard.readHTML(), rtf: clipboard.readRTF(), text: clipboard.readText() }));
ipcMain.handle('clipboard:paste', () => { win.webContents.paste(); return true; });

// Saves a report of exactly what another program put on the clipboard, so paste problems can be diagnosed
function clipboardCheck() {
  const formats = clipboard.availableFormats();
  const html = clipboard.readHTML();
  const rtf = clipboard.readRTF();
  const text = clipboard.readText();
  const cut = (s, n) => (s || '').length > n ? s.slice(0, n) + `\n... [${s.length - n} more characters]` : (s || '(empty)');
  const report = [
    'UNWIP CLIPBOARD CHECK',
    `Made: ${new Date().toString()}`,
    '',
    'Formats on the clipboard:',
    ...formats.map(f => '  - ' + f),
    '',
    '===== HTML =====', cut(html, 30000), '',
    '===== RTF =====', cut(rtf, 30000), '',
    '===== PLAIN TEXT (first 2000 characters) =====', cut(text, 2000)
  ].join('\r\n');
  const file = path.join(LIBRARY(), 'clipboard-check.txt');
  fs.writeFileSync(file, report);
  shell.showItemInFolder(file);
}

// ---------- Fonts ----------
ipcMain.handle('fonts:import', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Import font files',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Fonts', extensions: ['ttf', 'otf', 'woff', 'woff2'] }]
  });
  if (res.canceled) return [];
  for (const f of res.filePaths) fs.copyFileSync(f, path.join(FONT_DIR(), path.basename(f)));
  return listImportedFonts();
});
function listImportedFonts() {
  ensureDir(FONT_DIR());
  return fs.readdirSync(FONT_DIR())
    .filter(f => /\.(ttf|otf|woff2?)$/i.test(f))
    .map(f => ({ file: f, data: fs.readFileSync(path.join(FONT_DIR(), f)).toString('base64') }));
}
ipcMain.handle('fonts:imported', () => listImportedFonts());

// ---------- Export ----------
// Render HTML to PDF in a hidden window. opts: { pageSize, margins (inches), pageNumbers }
async function renderPDF(html, opts = {}) {
  const tmp = path.join(app.getPath('temp'), 'folio-export-' + Date.now() + '.html');
  fs.writeFileSync(tmp, html);
  const pw = new BrowserWindow({ show: false, webPreferences: { javascript: false, offscreen: OFFSCREEN } });
  try {
    await pw.loadFile(tmp);
    const m = opts.margins || { top: 0.9, bottom: 0.9, left: 0.9, right: 0.9 };
    const pdf = await pw.webContents.printToPDF({
      pageSize: opts.pageSize || 'A4',
      printBackground: true,
      margins: { marginType: 'custom', ...m },
      displayHeaderFooter: !!(opts.pageNumbers || opts.header),
      headerTemplate: opts.header ? `<div style="width:100%;text-align:right;padding-right:0.9in;font-family:'Times New Roman',serif;font-size:10px;color:#000">${String(opts.header).replace(/[<>&]/g, '')}<span class="pageNumber"></span></div>` : '<span></span>',
      footerTemplate: opts.pageNumbers ? `<div style="width:100%;text-align:center;font-family:${(opts.font || 'Times New Roman').replace(/[<>"]/g, '')},serif;font-size:9px;color:#333"><span class="pageNumber"></span></div>` : '<span></span>'
    });
    return pdf;
  } finally {
    pw.destroy();
    fs.rm(tmp, { force: true }, () => {});
  }
}
function countPdfPages(buf) {
  const m = buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g);
  return m ? m.length : 0;
}
ipcMain.handle('export:pdf', async (_e, html, suggestedName, pageSize, opts = {}) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export PDF',
    defaultPath: path.join(app.getPath('documents'), slugify(suggestedName) + '.pdf'),
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (res.canceled) return null;
  const pdf = await renderPDF(html, { ...opts, pageSize });
  fs.writeFileSync(res.filePath, pdf);
  shell.showItemInFolder(res.filePath);
  return { path: res.filePath, pages: countPdfPages(pdf) };
});
// exact page count without saving anything
ipcMain.handle('export:pdfPages', async (_e, html, pageSize, opts = {}) => countPdfPages(await renderPDF(html, { ...opts, pageSize })));

// save any generated file (e.g. EPUB) after asking where
ipcMain.handle('export:binary', async (_e, bytes, suggestedName, ext, label) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export ' + label,
    defaultPath: path.join(app.getPath('documents'), slugify(suggestedName) + '.' + ext),
    filters: [{ name: label, extensions: [ext] }]
  });
  if (res.canceled) return null;
  fs.writeFileSync(res.filePath, Buffer.from(bytes));
  shell.showItemInFolder(res.filePath);
  return res.filePath;
});

ipcMain.handle('export:html', async (_e, html, suggestedName) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export for Word / Google Docs',
    defaultPath: path.join(app.getPath('documents'), slugify(suggestedName) + '.html'),
    filters: [{ name: 'Web page (opens in Word and Google Docs)', extensions: ['html'] }]
  });
  if (res.canceled) return null;
  fs.writeFileSync(res.filePath, html);
  shell.showItemInFolder(res.filePath);
  return res.filePath;
});

// ---------- App settings (spelling language etc.), kept in a small file ----------
const SETTINGS_FILE = () => path.join(app.getPath('userData'), 'settings.json');
function loadSettings() { return readJSON(SETTINGS_FILE(), {}); }
function saveSettings(s) { writeFileSafe(SETTINGS_FILE(), JSON.stringify(s, null, 2)); }
function applySpellSettings() {
  const ses = session.defaultSession;
  const st = loadSettings();
  const avail = ses.availableSpellCheckerLanguages || [];
  let langs = (st.spellLangs || []).filter(l => avail.includes(l));
  if (!langs.length) langs = ['en-AU', 'en-GB', 'en-US'].filter(l => avail.includes(l)).slice(0, 1);
  try { if (langs.length) ses.setSpellCheckerLanguages(langs); } catch {}
  try { ses.setSpellCheckerEnabled(st.spellcheck !== false); } catch {}
}
ipcMain.handle('settings:get', () => loadSettings());
ipcMain.handle('settings:set', (_e, patch) => { const st = { ...loadSettings(), ...(patch || {}) }; saveSettings(st); return st; });
ipcMain.handle('settings:spell', () => {
  const ses = session.defaultSession;
  const st = loadSettings();
  return { available: ses.availableSpellCheckerLanguages || [], current: ses.getSpellCheckerLanguages(), enabled: st.spellcheck !== false };
});
ipcMain.handle('settings:setSpell', (_e, langs, enabled) => {
  const st = loadSettings();
  st.spellLangs = (langs || []).slice(0, 3);
  st.spellcheck = enabled !== false;
  saveSettings(st);
  applySpellSettings();
  return session.defaultSession.getSpellCheckerLanguages();
});
ipcMain.handle('spell:list', async () => { try { return await session.defaultSession.listWordsInSpellCheckerDictionary(); } catch { return []; } });
ipcMain.handle('spell:remove', (_e, word) => { try { return session.defaultSession.removeWordFromSpellCheckerDictionary(word); } catch { return false; } });

// ---------- Spellcheck: teach it the names from your character/place/item sheets ----------
ipcMain.handle('spell:add', (_e, words) => {
  const ses = win.webContents.session;
  for (const w of (words || []).slice(0, 2000)) { try { ses.addWordToSpellCheckerDictionary(String(w)); } catch {} }
  return true;
});

// ---------- Window ----------
ipcMain.handle('win:zoom', (e, f) => { const z = Math.min(1.5, Math.max(0.75, +f || 1)); e.sender.setZoomFactor(z); return z; });
ipcMain.handle('win:fullscreen', (_e, on) => { win.setFullScreen(!!on); return win.isFullScreen(); });
ipcMain.handle('find:start', (_e, text, opts) => { if (text) win.webContents.findInPage(text, opts || {}); });
ipcMain.handle('find:stop', () => win.webContents.stopFindInPage('keepSelection'));

// ---------- Updates ----------
// The app checks a public GitHub repo that only holds update packages (the code itself lives in a private repo).
// An update replaces the app's own files (app/, main.js, preload.js, package.json), never your projects.
// Each package is checked against its SHA-256 fingerprint before anything is written.
const { net } = require('electron');
const crypto = require('crypto');
const zlib = require('zlib');
const UPDATE_REPO = 'TreatonOCE/unwip-releases';
// first a small manifest file in the repo (fast, no API limits), then GitHub's Releases list as a backup
// While the releases repo is private, a read-only "update key" (a GitHub token limited to that one repo,
// pasted into Settings by the owner) lets Unwip read it. Without a key, the public addresses are used.
const updateKey = () => String(loadSettings().updateKey || '').trim();
const CONTENTS = p => `https://api.github.com/repos/${UPDATE_REPO}/contents/${p}?ref=main`;
const UPDATE_URLS = () => process.env.UNWIP_UPDATE_URL ? [process.env.UNWIP_UPDATE_URL] : updateKey() ? [CONTENTS('latest.json')] : [
  `https://raw.githubusercontent.com/${UPDATE_REPO}/main/latest.json`,
  `https://api.github.com/repos/${UPDATE_REPO}/releases/latest`
];
// where to download a package file from (the private route goes through GitHub's API with the key)
const assetURL = a => updateKey() && !process.env.UNWIP_UPDATE_URL ? CONTENTS('packages/' + encodeURIComponent(a.name)) : a.browser_download_url;
const UPDATE_TARGET = () => process.env.UNWIP_UPDATE_TARGET || app.getAppPath();
let updateState = { status: 'idle' };
const APP_VERSION = () => readJSON(path.join(__dirname, 'package.json'), {}).version || app.getVersion();   // idle | checking | none | downloading | ready | error

function versionNum(v) { return String(v || '0').replace(/^v/i, '').split(/[.-]/).slice(0, 3).map(n => parseInt(n, 10) || 0); }
function newer(a, b) { const x = versionNum(a), y = versionNum(b); for (let i = 0; i < 3; i++) { if (x[i] !== y[i]) return x[i] > y[i]; } return false; }

async function fetchBuf(url) {
  const headers = { 'User-Agent': 'Unwip-Updater', Accept: 'application/octet-stream, application/json' };
  if (/^https:\/\/api\.github\.com\//.test(url) && updateKey()) { headers.Authorization = `Bearer ${updateKey()}`; if (url.includes('/contents/')) headers.Accept = 'application/vnd.github.raw'; }
  const r = await net.fetch(url, { headers });
  if (r.status === 401) throw new Error('The update key was refused. It may have expired; make a new one and paste it into Settings → Updates.');
  if (r.status === 404 && !updateKey()) throw new Error('Updates are private. Add your update key in Settings → Updates.');
  if (!r.ok) throw new Error(`Download failed (${r.status})`);
  return Buffer.from(await r.arrayBuffer());
}
// minimal zip reader (stored + deflate), enough for our own update packages
function unzip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Not a zip file');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const files = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Damaged zip');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    const lnlen = buf.readUInt16LE(off + 26), lxlen = buf.readUInt16LE(off + 28);
    const data = buf.slice(off + 30 + lnlen + lxlen, off + 30 + lnlen + lxlen + csize);
    files.push({ name, data: method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : (() => { throw new Error('Unsupported zip'); })() });
  }
  return files;
}
const ALLOWED = name => !name.includes('..') && !path.isAbsolute(name) && !name.includes('\\') && (/^app\/[\w\-./]+$/.test(name) || ['main.js', 'preload.js', 'package.json'].includes(name));

async function checkForUpdate() {
  updateState = { status: 'checking' };
  try {
    let rel = null, lastErr = null;
    for (const url of UPDATE_URLS()) {
      try { const j = JSON.parse((await fetchBuf(url + (url.includes('raw.githubusercontent') ? `?t=${Date.now()}` : ''))).toString('utf8')); if (j && j.tag_name) { rel = j; break; } } catch (e) { lastErr = e; }
    }
    if (!rel) throw lastErr || new Error('No update information found');
    const version = String(rel.tag_name || '').replace(/^v/i, '');
    if (!version || !newer(version, APP_VERSION())) { updateState = { status: 'none', current: APP_VERSION() }; return updateState; }
    const zipA = (rel.assets || []).find(a => /\.zip$/i.test(a.name));
    const shaA = (rel.assets || []).find(a => /\.sha256$/i.test(a.name));
    if (!zipA) throw new Error('The update has no package');
    updateState = { status: 'available', version, notes: rel.body || '', zip: assetURL(zipA), sha: shaA ? assetURL(shaA) : null, shaInline: ((rel.body || '').match(/sha256:\s*([a-f0-9]{64})/i) || [])[1] || null };
    return updateState;
  } catch (e) { updateState = { status: 'error', error: String(e.message || e) }; return updateState; }
}

async function installUpdate() {
  if (updateState.status !== 'available') await checkForUpdate();
  if (updateState.status !== 'available') return updateState;
  const u = updateState;
  updateState = { ...u, status: 'downloading' };
  try {
    const zipBuf = await fetchBuf(u.zip);
    const want = (u.sha ? (await fetchBuf(u.sha)).toString('utf8') : u.shaInline || '').trim().split(/\s+/)[0].toLowerCase();
    const got = crypto.createHash('sha256').update(zipBuf).digest('hex');
    if (!/^[a-f0-9]{64}$/.test(want) || want !== got) throw new Error('The download didn’t match its fingerprint, so it wasn’t installed.');
    const files = unzip(zipBuf);
    if (!files.length || files.some(f => !ALLOWED(f.name))) throw new Error('The update package looks wrong, so it wasn’t installed.');
    const pkg = files.find(f => f.name === 'package.json');
    if (!pkg || !files.some(f => f.name === 'app/index.html') || !files.some(f => f.name === 'main.js')) throw new Error('The update package is incomplete.');
    const meta = JSON.parse(pkg.data.toString('utf8'));
    if (meta.unwipMinElectron && newer(meta.unwipMinElectron, process.versions.electron)) throw new Error('This update needs the full installer (a newer engine). Download it from the Unwip page.');
    // keep a copy of the current files, then write the new ones (each written safely: temp file, then rename)
    const target = UPDATE_TARGET();
    const backup = path.join(path.dirname(target), path.basename(target) + '-previous');
    fs.rmSync(backup, { recursive: true, force: true });
    fs.cpSync(target, backup, { recursive: true });
    try {
      for (const f of files) { const out = path.join(target, ...f.name.split('/')); ensureDir(path.dirname(out)); writeFileSafe(out, f.data); }
    } catch (e) {
      fs.cpSync(backup, target, { recursive: true, force: true });   // put everything back
      throw e;
    }
    const st = loadSettings(); st.justUpdated = { version: u.version, notes: u.notes, at: Date.now() }; saveSettings(st);
    updateState = { status: 'ready', version: u.version, notes: u.notes };
    return updateState;
  } catch (e) { updateState = { status: 'error', error: String(e.message || e) }; return updateState; }
}
ipcMain.handle('update:check', () => checkForUpdate());
ipcMain.handle('update:install', () => installUpdate());
ipcMain.handle('update:state', () => ({ ...updateState, current: APP_VERSION(), auto: app.isPackaged || !!process.env.UNWIP_UPDATE_URL }));
ipcMain.handle('app:relaunch', () => { app.relaunch(); app.exit(0); });


// ---------- Sync folders (Dropbox, OneDrive) ----------
function dropboxFolders() {
  const out = [];
  for (const base of [process.env.LOCALAPPDATA, process.env.APPDATA].filter(Boolean)) {
    const info = readJSON(path.join(base, 'Dropbox', 'info.json'), null);
    if (info) for (const k of ['personal', 'business']) if (info[k] && info[k].path && !out.includes(info[k].path)) out.push(info[k].path);
  }
  const guess = path.join(app.getPath('home'), 'Dropbox');
  if (!out.length && fs.existsSync(guess)) out.push(guess);
  return out;
}
ipcMain.handle('library:info', () => {
  const lib = LIBRARY();
  const places = [];
  for (const d of dropboxFolders()) places.push({ kind: 'dropbox', label: 'Dropbox', path: path.join(d, 'Unwip'), exists: fs.existsSync(path.join(d, 'Unwip')) });
  for (const o of [process.env.OneDrive, process.env.OneDriveConsumer].filter(Boolean)) if (!places.some(p => p.path === path.join(o, 'Unwip'))) places.push({ kind: 'onedrive', label: 'OneDrive', path: path.join(o, 'Unwip'), exists: fs.existsSync(path.join(o, 'Unwip')) });
  places.push({ kind: 'default', label: 'This PC only (Documents)', path: DEFAULT_LIBRARY(), exists: fs.existsSync(DEFAULT_LIBRARY()) });
  const cur = path.resolve(lib).toLowerCase();
  const kind = (places.find(p => path.resolve(p.path).toLowerCase() === cur) || { kind: 'custom' }).kind;
  return { path: lib, kind, places, parentMissing: !fs.existsSync(path.dirname(lib)), device: require('os').hostname() };
});
ipcMain.handle('library:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose where to keep your Unwip projects', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths.length) return null;
  const p = r.filePaths[0];
  return /unwip$/i.test(path.basename(p)) ? p : path.join(p, 'Unwip');
});
// Move (or merge) the whole library into another folder. Nothing is deleted: the old folder is renamed and kept.
ipcMain.handle('library:move', (_e, target) => {
  const from = path.resolve(LIBRARY()), to = path.resolve(String(target || ''));
  if (!target || from.toLowerCase() === to.toLowerCase()) return { ok: true, moved: 0, path: from };
  if (to.toLowerCase().startsWith(from.toLowerCase() + path.sep)) throw new Error('Pick a folder outside your current library.');
  ensureDir(to);
  let moved = 0, kept = 0;
  if (fs.existsSync(from)) {
    for (const d of fs.readdirSync(from, { withFileTypes: true })) {
      const src = path.join(from, d.name);
      let dest = path.join(to, d.name);
      if (fs.existsSync(dest)) {
        if (d.name === '_Play') { mergePlay(src, dest); continue; }
        const a = readJSON(path.join(src, 'project.json'), null), b = readJSON(path.join(dest, 'project.json'), null);
        if (a && b && a.created && a.created === b.created && (b.modified || 0) >= (a.modified || 0)) { kept++; continue; }   // same project, the synced copy is newer
        let n = 2; while (fs.existsSync(dest)) dest = path.join(to, `${d.name} (from ${require('os').hostname()}${n > 2 ? ' ' + n : ''})`), n++;
      }
      fs.cpSync(src, dest, { recursive: true });
      moved++;
    }
  }
  const st = loadSettings(); st.libraryPath = path.resolve(to) === path.resolve(DEFAULT_LIBRARY()) ? null : to; saveSettings(st);
  libraryOverride = st.libraryPath || null;
  // keep the old folder, renamed, as a safety copy
  let old = null;
  if (fs.existsSync(from) && moved + kept > 0) {
    old = from + ' (old copy)'; let n = 2; while (fs.existsSync(old)) old = `${from} (old copy ${n++})`;
    try { fs.renameSync(from, old); } catch { old = from; }
  }
  return { ok: true, moved, kept, path: to, old };
});
function mergePlay(src, dest) {
  const a = readJSON(path.join(src, 'play.json'), { pieces: [], days: {} }), b = readJSON(path.join(dest, 'play.json'), { pieces: [], days: {} });
  const ids = new Set((b.pieces || []).map(p => p.id));
  b.pieces = [...(b.pieces || []), ...(a.pieces || []).filter(p => !ids.has(p.id))];
  for (const [d, n] of Object.entries(a.days || {})) b.days[d] = Math.max(b.days[d] || 0, n);
  writeFileSafe(path.join(dest, 'play.json'), JSON.stringify(b, null, 2));
  const sp = path.join(src, 'pieces'); if (fs.existsSync(sp)) { const dp = ensureDir(path.join(dest, 'pieces')); for (const f of fs.readdirSync(sp)) if (!fs.existsSync(path.join(dp, f))) fs.copyFileSync(path.join(sp, f), path.join(dp, f)); }
}

// ---------- Working on two devices ----------
// While a project is open, a small "open on <device>" note sits in its folder (refreshed every minute),
// so another device opening the same project can warn first.
const deviceName = () => require('os').hostname().replace(/[^\w-]/g, '') || 'this-pc';
const presenceFile = slug => path.join(projectDir(slug), `.open-on-${deviceName()}.json`);
let presenceSlug = null;
app.on('before-quit', () => { if (presenceSlug) try { fs.rmSync(presenceFile(presenceSlug), { force: true }); } catch {} });
ipcMain.handle('project:presence', (_e, slug, on) => {
  presenceSlug = on ? slug : null;
  try { if (on) fs.writeFileSync(presenceFile(slug), JSON.stringify({ device: require('os').hostname(), at: Date.now() })); else fs.rmSync(presenceFile(slug), { force: true }); } catch {}
  return true;
});
ipcMain.handle('project:others', (_e, slug) => {
  const dir = projectDir(slug), mine = path.basename(presenceFile(slug));
  return fs.readdirSync(dir).filter(f => /^\.open-on-.+\.json$/.test(f) && f !== mine)
    .map(f => readJSON(path.join(dir, f), null)).filter(x => x && Date.now() - x.at < 90000);
});
// "Please close it there": a note in the project folder that the other device sees within seconds of Dropbox syncing it
const takeoverFile = slug => path.join(projectDir(slug), '.takeover.json');
ipcMain.handle('project:requestTakeover', (_e, slug, on) => {
  try { if (on) fs.writeFileSync(takeoverFile(slug), JSON.stringify({ by: require('os').hostname(), at: Date.now() })); else fs.rmSync(takeoverFile(slug), { force: true }); } catch {}
  return true;
});
ipcMain.handle('project:checkTakeover', (_e, slug) => {
  const t = readJSON(takeoverFile(slug), null);
  return t && t.by !== require('os').hostname() && Date.now() - t.at < 180000 ? t : null;
});
// what this computer last saw of each document (kept on this PC only), to highlight changes made elsewhere
const seenFile = (slug, id) => path.join(ensureDir(path.join(app.getPath('userData'), 'seen', safeId(slug.replace(/[^\w-]+/g, '_')))), safeId(id) + '.html');
ipcMain.handle('seen:load', (_e, slug, id) => { try { const f = seenFile(slug, id); return { html: fs.readFileSync(f, 'utf8'), at: fs.statSync(f).mtimeMs }; } catch { return null; } });
ipcMain.handle('seen:save', (_e, slug, id, html) => { try { fs.writeFileSync(seenFile(slug, id), html); } catch {} return true; });
// Dropbox keeps both versions when two devices change the same file, as "name (DEVICE's conflicted copy DATE)".
const CONFLICT = /\s*\(([^()]*?)(?:['’]s)?\s*conflicted copy[^()]*\)/i;
ipcMain.handle('project:conflicts', (_e, slug) => {
  const dir = projectDir(slug), out = [];
  const scan = (sub, kind) => { const d = path.join(dir, sub); if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d)) { const m = CONFLICT.exec(f); if (!m) continue; out.push({ file: path.posix.join(sub, f), kind, device: m[1].trim() || 'another device', original: f.replace(CONFLICT, '') }); } };
  scan('.', 'project'); scan('docs', 'doc');
  return out.filter(c => c.kind === 'doc' ? /\.html$/.test(c.original) : c.original === 'project.json');
});
ipcMain.handle('project:readConflict', (_e, slug, file) => {
  const p = path.resolve(projectDir(slug), file);
  if (!p.startsWith(path.resolve(projectDir(slug))) || !CONFLICT.test(path.basename(p))) throw new Error('Bad file');
  return fs.readFileSync(p, 'utf8');
});
ipcMain.handle('project:archiveConflict', (_e, slug, file) => {
  const p = path.resolve(projectDir(slug), file);
  if (!p.startsWith(path.resolve(projectDir(slug))) || !CONFLICT.test(path.basename(p))) throw new Error('Bad file');
  const d = ensureDir(path.join(projectDir(slug), 'backups', 'sync-conflicts'));
  fs.renameSync(p, path.join(d, Date.now() + ' ' + path.basename(p)));
  return true;
});
// Notice when another device changes this project's files (Dropbox writing them in)
let watcher = null, watchTimers = {};
ipcMain.handle('project:watch', (_e, slug) => {
  try { if (watcher) watcher.close(); } catch {}
  watcher = null;
  if (!slug) return true;
  const dir = projectDir(slug);
  try {
    watcher = fs.watch(dir, { recursive: true }, (_ev, name) => {
      if (!name) return;
      const rel = String(name).replace(/\\/g, '/');
      if (!(rel === 'project.json' || /^docs\/[\w-]+\.html$/.test(rel))) return;
      clearTimeout(watchTimers[rel]);
      watchTimers[rel] = setTimeout(() => {
        const full = path.resolve(dir, rel);
        let data; try { data = fs.readFileSync(full); } catch { return; }
        if (written.get(full) === fingerprint(data)) return;   // our own save
        written.set(full, fingerprint(data));
        if (win && !win.isDestroyed()) win.webContents.send('project:external', { slug, file: rel, id: rel.startsWith('docs/') ? rel.slice(5, -5) : null });
      }, 900);
    });
  } catch {}
  return true;
});

// ---------- Full backups (.unwip files) ----------
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zipFiles(files) {   // [{name, data: Buffer}] -> Buffer (deflate)
  const parts = [], central = []; let off = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'utf8'), comp = zlib.deflateRawSync(f.data), crc = crc32(f.data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8);
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(f.data.length, 22); h.writeUInt16LE(name.length, 26);
    parts.push(h, name, comp);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(f.data.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(off, 42);
    central.push(c, name); off += 30 + name.length + comp.length;
  }
  const cen = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cen.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cen, end]);
}
function projectArchive(slug) {
  const dir = projectDir(slug), files = [];
  const walk = (d, rel) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const r = rel ? rel + '/' + e.name : e.name;
    if (e.isDirectory()) { if (!rel && e.name === 'backups') continue; walk(path.join(d, e.name), r); }
    else if (!/^\.open-on-|\.tmp$/.test(e.name) && !CONFLICT.test(e.name)) files.push({ name: r, data: fs.readFileSync(path.join(d, e.name)) });
  } };
  walk(dir, '');
  return zipFiles(files);
}
const dateStamp = () => new Date().toLocaleDateString('en-CA');
ipcMain.handle('backup:export', async (_e, slug) => {
  const p = readJSON(path.join(projectDir(slug), 'project.json'), {});
  const r = await dialog.showSaveDialog(win, { title: 'Save a full backup', defaultPath: path.join(app.getPath('documents'), `${slugify(p.title || slug)} ${dateStamp()}.unwip`), filters: [{ name: 'Unwip backup', extensions: ['unwip'] }] });
  if (r.canceled || !r.filePath) return null;
  fs.writeFileSync(r.filePath, projectArchive(slug));
  return r.filePath;
});
function restoreArchive(buf, titleSuffix) {
  const files = unzip(buf);
  const pj = files.find(f => f.name === 'project.json');
  if (!pj) throw new Error('This isn’t an Unwip backup.');
  const project = JSON.parse(pj.data.toString('utf8'));
  project.title = (project.title || 'Restored project') + (titleSuffix || '');
  let base = slugify(project.title), slug = base, n = 2;
  while (fs.existsSync(path.join(LIBRARY(), slug))) slug = `${base} (${n++})`;
  const dir = ensureDir(projectDir(slug));
  for (const f of files) {
    if (f.name.includes('..') || path.isAbsolute(f.name)) continue;
    const out = path.join(dir, ...f.name.split('/')); ensureDir(path.dirname(out));
    fs.writeFileSync(out, f.name === 'project.json' ? JSON.stringify({ ...project, modified: Date.now() }, null, 2) : f.data);
  }
  ensureDir(path.join(dir, 'docs'));
  return slug;
}
ipcMain.handle('backup:importFile', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Restore from a backup file', properties: ['openFile'], filters: [{ name: 'Unwip backup', extensions: ['unwip', 'zip'] }] });
  if (r.canceled || !r.filePaths.length) return null;
  return restoreArchive(fs.readFileSync(r.filePaths[0]), ' (restored)');
});
ipcMain.handle('backup:list', (_e, slug) => {
  const bdir = path.join(projectDir(slug), 'backups');
  if (!fs.existsSync(bdir)) return [];
  return fs.readdirSync(bdir).filter(f => /^\d{4}-/.test(f)).sort().reverse().map(stamp => {
    const docs = path.join(bdir, stamp, 'docs'); let n = 0, size = 0;
    try { for (const f of fs.readdirSync(docs)) { n++; size += fs.statSync(path.join(docs, f)).size; } } catch {}
    const pj = readJSON(path.join(bdir, stamp, 'project.json'), {});
    return { stamp, docs: n, size, words: pj.totalWords || 0 };
  });
});
// restoring an automatic backup makes a separate copy of the project, so nothing current is overwritten
ipcMain.handle('backup:restore', (_e, slug, stamp) => {
  const dir = projectDir(slug), b = path.join(dir, 'backups', path.basename(String(stamp)));
  if (!fs.existsSync(path.join(b, 'project.json'))) throw new Error('That backup is missing.');
  const files = [{ name: 'project.json', data: fs.readFileSync(path.join(b, 'project.json')) }];
  for (const f of fs.readdirSync(path.join(b, 'docs'))) files.push({ name: 'docs/' + f, data: fs.readFileSync(path.join(b, 'docs', f)) });
  for (const md of [path.join(dir, 'backups', 'media'), path.join(dir, 'media')]) if (fs.existsSync(md)) for (const f of fs.readdirSync(md)) if (!files.some(x => x.name === 'media/' + f)) files.push({ name: 'media/' + f, data: fs.readFileSync(path.join(md, f)) });
  const d = new Date(stamp.slice(0, 10) + 'T' + stamp.slice(11, 19).replace(/-/g, ':') + 'Z');   // stamps are stored in UTC
  const when = isNaN(d) ? stamp.slice(0, 10) : `${d.toLocaleDateString('en-CA')} ${String(d.getHours()).padStart(2, '0')}.${String(d.getMinutes()).padStart(2, '0')}`;
  return restoreArchive(zipFiles(files), ` (backup ${when})`);
});
// Optional extra copy somewhere else (a USB stick, another drive, a different cloud): once a day per project, last 10 kept
function extraBackup(slug, force) {
  const st = loadSettings(); const to = st.extraBackupDir;
  if (!to || !fs.existsSync(to)) return null;
  const p = readJSON(path.join(projectDir(slug), 'project.json'), {});
  const prefix = slugify(p.title || slug) + ' ';
  const mine = fs.readdirSync(to).filter(f => f.startsWith(prefix) && f.endsWith('.unwip')).sort();
  const todays = prefix + dateStamp() + '.unwip';
  if (!force && mine.includes(todays)) return null;
  try { fs.writeFileSync(path.join(to, todays), projectArchive(slug)); } catch { return null; }
  const all = fs.readdirSync(to).filter(f => f.startsWith(prefix) && f.endsWith('.unwip')).sort();
  while (all.length > 10) { try { fs.rmSync(path.join(to, all.shift())); } catch { break; } }
  return todays;
}
ipcMain.handle('backup:extraPick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose a folder for extra backup copies', properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
});
ipcMain.handle('backup:extraNow', (_e, slug) => extraBackup(slug, true));

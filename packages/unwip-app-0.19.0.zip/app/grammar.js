// Unwip - grammar checks. Rule-based, offline, no AI.
// Three groups, shown in Revise:
//   grammar  - a/an, "could of", "they was", "between you and I", "lets go", lowercase "i", dialogue punctuation, missing question marks
//   confused - its/it's, your/you're, their/there/they're, then/than, lose/loose, affect/effect, whose/who's, to/too, breath/breathe…
//   spelling - mixing UK and US spellings in the same chapter (colour and color)
// Every rule is written to be precise rather than clever: it only flags patterns that are almost always wrong.
// Agreement rules ("he don't", "they was") skip dialogue, where characters may talk that way on purpose.
window.UnwipGrammar = (function () {
  'use strict';
  const AP = "['’]";
  const SAID = 'said|asked|whispered|muttered|mumbled|replied|shouted|yelled|called|cried|added|answered|murmured|snapped|hissed|growled|sighed|laughed|continued|began|explained|admitted|insisted|demanded|offered|suggested|warned|agreed|repeated|grumbled|groaned|breathed|stammered|exclaimed|retorted|interrupted|whimpered|pleaded|begged|announced|declared|said';
  // verbs of speaking only: after "She laughed." or "I began to…" a full stop is right (that's an action, not a tag)
  const SPEECH = 'said|asked|whispered|muttered|mumbled|replied|shouted|yelled|called|cried|added|answered|murmured|snapped|hissed|growled|explained|admitted|insisted|demanded|offered|suggested|warned|agreed|repeated|grumbled|stammered|exclaimed|retorted|interrupted|pleaded|begged|announced|declared|whined|lied|promised|joked|teased|corrected|noted|remarked|stated|told|called out';
  const AUX = new Set('did does do would could should will can may might must to let make made help helped watch watched saw see hear heard had shall wo ca'.split(' '));

  // keep the writer's capitals when suggesting a replacement
  function keepCase(orig, repl) {
    if (orig === orig.toUpperCase() && /[A-Z]/.test(orig) && orig.length > 1) return repl.toUpperCase();
    if (/^[A-Z]/.test(orig)) return repl[0].toUpperCase() + repl.slice(1);
    return repl;
  }
  // character ranges that are inside quotation marks (dialogue)
  function dialogueRanges(text) {
    const out = []; let open = -1;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (c === '“') open = i;
      else if (c === '”' && open >= 0) { out.push([open, i]); open = -1; }
      else if (c === '"') { if (open >= 0) { out.push([open, i]); open = -1; } else open = i; }
    }
    if (open >= 0) out.push([open, text.length]);   // dialogue that runs on to the next paragraph
    return out;
  }
  const inside = (ranges, i) => ranges.some(([a, b]) => i > a && i < b);
  const wordBefore = (text, i) => { const m = /([\p{L}’']+)\s*$/u.exec(text.slice(Math.max(0, i - 30), i)); return m ? m[1].toLowerCase() : ''; };

  // ---------------------------------------------------------------- a / an
  const CONS_SOUND = /^(uni(?!nt|mp|nh|nd)|use|usu|usa|ura|uri|ure|uro|uti|eu|ewe|one\b|once|ubiq|ufo|ukr|uk\b|u\.s)/i;
  const VOWEL_SOUND = /^(hour|honest|honou?r|heir|herb\b)/i;
  function needsAn(word) {
    if (/^\d/.test(word)) return /^(8|11|18|8\d)(\D|$)/.test(word) || /^8\d\d/.test(word);
    if (/^[A-Z]{2,}/.test(word)) return null;                                   // capitals: an acronym (an FBI agent) or shouting (A LOT) - can't tell, so leave it
    if (VOWEL_SOUND.test(word)) return true;
    if (CONS_SOUND.test(word)) return false;
    return /^[aeiou]/i.test(word);
  }

  // ---------------------------------------------------------------- the rule list
  // [cat, regex, message, replacement(match) -> text for the highlighted part, options]
  // options.group: which capture group is highlighted and replaced (default: whole match)
  // options.guard(text, m, ctx): return false to skip ; options.notInDialogue
  const R = [];
  const rule = (cat, re, msg, repl, opt = {}) => R.push({ cat, re, msg, repl, ...opt });
  const w = s => new RegExp(s, 'giu');

  // grammar
  rule('grammar', w(`\\b(could|should|would|must|might|may)\\s+of\\b(?!\\s+course)`), 'After “could”, “should” and “would” it’s “have”, not “of”.', m => keepCase(m[0], `${m[1]} have`));
  rule('grammar', w(`\\b(between\\s+(?:you|him|her|them|us))\\s+and\\s+I\\b`), '“Between you and me”: after “between” it’s “me”.', m => `${m[1]} and me`);
  rule('grammar', w(`\\b(he|she|it)\\s+(don${AP}t|have|were|are)\\b`), 'Agreement: “he/she/it” takes “doesn’t / has / was / is”.',
    m => `${m[1]} ${{ have: 'has', were: 'was', are: 'is' }[m[2].toLowerCase()] || 'doesn’t'}`,
    { notInDialogue: true, guard: (t, m) => { const b = wordBefore(t, m.index); if (AUX.has(b)) return false; if (/were/i.test(m[2]) && /\b(if|wish|wished|though|as)\b[^.!?]{0,20}$/i.test(t.slice(Math.max(0, m.index - 25), m.index))) return false; return true; } });
  rule('grammar', w(`\\b(they|we|you)\\s+(was|is|has|doesn${AP}t)\\b`), 'Agreement: “they/we/you” takes “were / are / have / don’t”.',
    m => `${m[1]} ${{ was: 'were', is: 'are', has: 'have' }[m[2].toLowerCase()] || 'don’t'}`, { notInDialogue: true, guard: (t, m) => !AUX.has(wordBefore(t, m.index)) });
  rule('grammar', /\bI\s+(is|are|has)\b/gu, 'Agreement: “I am”, “I have”.', m => `I ${{ is: 'am', are: 'am', has: 'have' }[m[1].toLowerCase()]}`, { notInDialogue: true, guard: (t, m) => !AUX.has(wordBefore(t, m.index)) });
  rule('grammar', w(`\\blets\\s+(?=(go|get|do|see|be|try|just|make|talk|have|hope|say|move|start|find|eat|not|keep|leave|check|take|stop|face|pretend|assume|agree)\\b)`), '“Let’s” (let us) needs an apostrophe.', m => keepCase(m[0], 'let’s '),
    { guard: (t, m) => { const b = wordBefore(t, m.index); return !b || /^(so|now|okay|ok|well|then|and|but|on|please|alright|right|oh|yes|no|come|just|hey|guys)$/.test(b) || /[“"(]\s*$/.test(t.slice(Math.max(0, m.index - 2), m.index)); } });
  rule('grammar', /(^|[\s“"(])i(?=(['’](m|ll|d|ve|s))?(?=[\s,.!?;:”"]|$))/gu, 'The word “I” is always a capital.', m => `${m[1]}I`, { guard: (t, m) => !/^\.[a-z]\./i.test(t.slice(m.index + m[0].length, m.index + m[0].length + 3)) });
  rule('grammar', w(`\\b(alot|infact|aswell|eachother|atleast|incase|irregardless|alright already)\\b`), 'This is usually written as two words (or differently).',
    m => keepCase(m[0], { alot: 'a lot', infact: 'in fact', aswell: 'as well', eachother: 'each other', atleast: 'at least', incase: 'in case', irregardless: 'regardless' }[m[0].toLowerCase()] || m[0]));
  rule('grammar', w(`\\bcould care less\\b`), 'The idiom is “couldn’t care less”.', m => keepCase(m[0], 'couldn’t care less'));
  rule('grammar', w(`\\bfor all intensive purposes\\b`), 'The phrase is “for all intents and purposes”.', m => keepCase(m[0], 'for all intents and purposes'));
  rule('grammar', w(`\\b(was|were|is|are|am|be|been|not)\\s+suppose\\s+to\\b`), '“Supposed to”, with a d.', m => `${m[1]} supposed to`);
  rule('grammar', w(`\\b(I|he|she|we|they|you|it)\\s+use\\s+to\\b`), '“Used to”, with a d (except after “didn’t”).', m => `${m[1]} used to`, { guard: (t, m) => !/n['’]t$|did$/i.test(wordBefore(t, m.index)) });
  // dialogue: “Hello.” she said  ->  “Hello,” she said
  rule('grammar', new RegExp(`([\\p{L}\\p{N}])\\.(["”])(\\s+(?:he|she|they|I|we|you|it)\\s+(?:${SPEECH})\\b)(?!\\s+(?:to|that|him|her|them|me|us)\\b)`, 'gu'), 'Dialogue followed by “she said” ends in a comma, not a full stop.', m => `${m[1]},${m[2]}${m[3]}`);
  // dialogue: “Hello,” She said  ->  “Hello,” she said
  rule('grammar', new RegExp(`(,["”]\\s+)(He|She|They|We|It)(\\s+(?:${SAID})\\b)`, 'gu'), 'After a comma and closing quote, the dialogue tag starts with a small letter.', m => `${m[1]}${m[2].toLowerCase()}${m[3]}`);
  // “Are you coming.”  ->  “Are you coming?”
  rule('grammar', /([“"])((?:Do|Does|Did|Can|Could|Would|Will|Are|Is|Have|Has|Should|Shall|Was|Were)\s+(?:you|I|we|they|he|she|it|there)\b[^“”"?!.,]{0,60})\.(["”])/gu, 'This looks like a question. Should it end with a question mark?', m => `${m[1]}${m[2]}?${m[3]}`, { guard: (t, m) => !/\bplease\b/i.test(m[2]) });

  // confused words
  rule('confused', w(`\\bit${AP}s\\s+own\\b`), '“Its own” (belonging to it) has no apostrophe.', m => keepCase(m[0], 'its own'));
  rule('confused', w(`\\bits\\s+(a|an|the|not|been|going|gonna|raining|okay|ok|too|so|very|always|never|almost|already|probably|definitely|really|fine|alright|cold|hot|over|me|you|him|her|us|them)\\b`), '“It’s” (it is / it has) needs an apostrophe here.', m => keepCase(m[0].split(/\s+/)[0], 'it’s') + ' ' + m[1]);
  rule('confused', /\bits['’](?=\s)/gu, '“Its” (belonging to it) has no apostrophe, and “it’s” means it is.', () => 'its');
  rule('confused', w(`\\byour\\s+(welcome|going|being|not|so|too|very|always|never|kidding|joking|lying|crazy|mad|insane|sure|done|late|early|gonna|already|still|probably|definitely|really|making|doing|getting|coming|looking|trying|telling|asking|talking|the|a|an)\\b`), '“You’re” (you are) needs an apostrophe here.', m => keepCase(m[0].split(/\s+/)[0], 'you’re') + ' ' + m[1],
    { guard: (t, m) => !/ing$/i.test(m[1]) || !/^\s+(?:away\s+)?(party|rate|price|concern|trip|plan|plans|habit|habits|career|style|days|years|skills?|partner|shoes|clothes)\b/i.test(t.slice(m.index + m[0].length, m.index + m[0].length + 30)) });
  rule('confused', w(`\\btheir\\s+(is|are|was|were|isn${AP}t|aren${AP}t|wasn${AP}t|weren${AP}t)\\b`), '“There is / there was”: the place word is “there”.', m => keepCase(m[0].split(/\s+/)[0], 'there') + ' ' + m[1]);
  rule('confused', w(`\\b(there|they${AP}re)\\s+own\\b`), '“Their own” (belonging to them).', m => keepCase(m[1], 'their') + ' own');
  rule('confused', w(`\\btheir\\s+(going|coming|not|always|never|so|too|very|probably|definitely|really|gonna|here|gone)\\b`), '“They’re” (they are) needs an apostrophe here.', m => keepCase(m[0].split(/\s+/)[0], 'they’re') + ' ' + m[1]);
  rule('confused', w(`\\bthere\\s+(car|house|home|eyes|hands|faces|heads|feet|friends|parents|mother|father|kids|children|names|lives|room|bags|clothes|hair|money|things|weapons|swords|horses|bodies|voices|minds|hearts)\\b`), '“Their” (belonging to them).', m => keepCase(m[0].split(/\s+/)[0], 'their') + ' ' + m[1], { guard: (t, m) => !/\b(over|in|out|up|down|from|back|get|got|been|is|was|are|were)\s*$/i.test(t.slice(Math.max(0, m.index - 12), m.index)) });
  rule('confused', w(`\\b(more|less|better|worse|rather|other|bigger|smaller|faster|slower|older|younger|greater|fewer|larger|longer|shorter|higher|lower|easier|harder|stronger|weaker|quicker|louder|darker|brighter|happier|colder|warmer|taller|closer|heavier|richer|smarter)\\s+then\\b`), 'Comparisons use “than” (better than), not “then”.', m => `${m[1]} than`, { guard: (t, m) => !/^(more|other)$/i.test(m[1]) || !/\b(once|no|any|some|every|each|the)\s*$/i.test(t.slice(Math.max(0, m.index - 6), m.index)) });
  rule('confused', w(`\\b(and|just|since|back|until|right)\\s+than\\b`), 'For time (and then, back then) it’s “then”.', m => `${m[1]} then`);
  rule('confused', w(`\\bloose\\s+(the|my|your|his|her|their|our|it|them|him|me|weight|track|control|sleep|interest|hope|focus|consciousness|money|everything|anything|sight|touch|faith|heart)\\b`), '“Lose” (to misplace or not win). “Loose” means not tight.', m => keepCase(m[0].split(/\s+/)[0], 'lose') + ' ' + m[1]);
  rule('confused', w(`\\b(will|could|would|might|may|didn${AP}t|don${AP}t|not|never|can${AP}t|cannot|wo?n${AP}t)\\s+loose\\b`), '“Lose” (to misplace or not win). “Loose” means not tight.', m => `${m[1]} lose`);
  rule('confused', w(`\\b(an|the|no|any|side|special|the same|a big|a huge|a strange|an odd)\\s+affect\\b`), 'The noun is usually “effect” (the effect, side effects).', m => `${m[1]} effect`);
  rule('confused', w(`\\b(will|to|could|would|might|may|didn${AP}t|doesn${AP}t|not|never|can)\\s+effect\\s+(the|my|your|his|her|their|our|me|him|them|us|everyone|anyone)\\b`), 'The verb is usually “affect” (it affects me).', m => `${m[1]} affect ${m[2]}`);
  rule('confused', w(`\\bwhose\\s+(going|been|coming|there|that|this|not|gonna|the|a|an)\\b`), '“Who’s” (who is / who has).', m => keepCase(m[0].split(/\s+/)[0], 'who’s') + ' ' + m[1]);
  rule('confused', w(`\\b(is|was|are|were|be|been|far|way|much|it${AP}s|that${AP}s|I${AP}m|you${AP}re|getting|got)\\s+to\\s+(much|many|late|early|soon|far|bad|big|small|long|hard|easy|good|little|close|tired|busy|young|old|cold|hot|loud|quiet|fast|slow|heavy|dark|bright|tight|weak|scared|afraid|proud|deep)\\b(?!\\s+(?:to|for)\\b)`), 'Here it should be “too” (meaning excessively).', m => `${m[1]} too ${m[2]}`);
  rule('confused', w(`(^|[“",]\\s*)(me|you)\\s+to([.!?])`), 'Meaning “also”, it’s “too”.', m => `${m[1]}${m[2]} too${m[3]}`);
  rule('confused', w(`\\b(to|could|couldn${AP}t|can${AP}t|cannot|can|didn${AP}t|don${AP}t|not|never|must|will|would|barely|hardly)\\s+breath\\b`), 'The verb is “breathe” (with an e). “Breath” is the noun.', m => `${m[1]} breathe`);
  rule('confused', w(`\\b(a|deep|the|my|his|her|their|your|our|of|shaky|ragged|sharp)\\s+breathe\\b`), 'The noun is “breath”. “Breathe” is the verb.', m => `${m[1]} breath`);
  rule('confused', w(`\\bsneak\\s+peak\\b`), 'A quick look is a “peek”.', m => keepCase(m[0].split(/\s+/)[0], 'sneak') + ' peek');
  rule('confused', w(`\\b(took|take|taking|takes|have|had|get|got)\\s+a\\s+peak\\b`), 'A quick look is a “peek”.', m => `${m[1]} a peek`);
  rule('confused', w(`\\bpeaked\\s+(my|his|her|their|your|our)\\s+(interest|curiosity)\\b`), 'Interest is “piqued”.', m => keepCase(m[0].split(/\s+/)[0], 'piqued') + ` ${m[1]} ${m[2]}`);
  rule('confused', w(`\\b(walked|ran|drove|went|rushed|hurried|moved|swept|slipped|strode|marched|raced|sped|flew|walk|run|drive|go)\\s+passed\\b`), 'Moving by something is “past”. “Passed” is the verb.', m => `${m[1]} past`);
  rule('confused', w(`\\b(had|has|have)\\s+lead\\b(?!\\s+(?:in|poisoning|pipe|weight))`), 'The past of “lead” is “led”.', m => `${m[1]} led`);
  rule('confused', w(`\\b(to|will|would|could|I|we|they)\\s+advice\\b`), 'The verb is “advise”. “Advice” is the noun.', m => `${m[1]} advise`);
  rule('confused', w(`\\b(some|good|bad|my|your|his|her|their|any|the|of|for|piece of)\\s+advise\\b`), 'The noun is “advice”. “Advise” is the verb.', m => `${m[1]} advice`);
  rule('confused', w(`\\bexcept\\s+((?:the|my|his|her|their|your|an?)\\s+)?(offer|invitation|apology|gift|award|job|position|challenge|terms|proposal)\\b`), 'To take something offered is “accept”.', m => keepCase(m[0].split(/\s+/)[0], 'accept') + ` ${m[1] || ''}${m[2]}`);
  rule('confused', w(`\\bweather\\s+or\\s+not\\b`), '“Whether or not” (if). “Weather” is rain and sun.', m => keepCase(m[0].split(/\s+/)[0], 'whether') + ' or not');
  rule('confused', w(`\\b(be|was|is|so|too|stay|stayed|keep|kept|fell|went|grew|remained|very|been)\\s+quite(?=[.,!?;”"])`), 'Silent is “quiet”. “Quite” means very or completely.', m => `${m[1]} quiet`);
  rule('confused', w(`\\b(should|would|could|must|might|will|to)\\s+of\\s+(?=\\w+ed\\b)`), '“Have”, not “of”.', m => `${m[1]} have `);

  // ---------------------------------------------------------------- UK / US spelling, only when one chapter mixes both
  const PAIRS = [];
  const our = ['colour', 'favour', 'honour', 'humour', 'labour', 'neighbour', 'rumour', 'behaviour', 'harbour', 'armour', 'flavour', 'odour', 'vapour', 'splendour', 'valour', 'clamour', 'glamour', 'savour', 'parlour', 'endeavour', 'vigour', 'rigour', 'saviour', 'candour'];
  for (const u of our) { const us = u.replace(/our$/, 'or'); for (const s of ['', 's', 'ed', 'ing', 'ful', 'less', 'able', 'ite', 'ites', 'ably', 'er', 'ers']) PAIRS.push([u + s, us + s]); }
  for (const [u, us] of [['centre', 'center'], ['theatre', 'theater'], ['litre', 'liter'], ['fibre', 'fiber'], ['sombre', 'somber'], ['spectre', 'specter'], ['sabre', 'saber'], ['lustre', 'luster'], ['calibre', 'caliber'], ['meagre', 'meager']])
    for (const s of ['', 's', 'd']) PAIRS.push([u + s, us + s]);
  const ise = ['realis', 'recognis', 'organis', 'apologis', 'emphasis', 'criticis', 'sympathis', 'memoris', 'agonis', 'paralys', 'analys', 'civilis', 'characteris', 'authoris', 'prioritis', 'minimis', 'maximis', 'summaris', 'visualis', 'utilis', 'mesmeris', 'terroris', 'tantalis', 'scrutinis', 'familiaris'];
  for (const b of ise) { const us = b.replace(/s$/, 'z'); for (const s of ['e', 'es', 'ed', 'ing', 'ation', 'ations']) { if (b === 'emphasis' && s === 'e') continue; PAIRS.push([b + s, us + s]); } }
  for (const pr of [['grey', 'gray'], ['greys', 'grays'], ['greyish', 'grayish'], ['travelled', 'traveled'], ['travelling', 'traveling'], ['traveller', 'traveler'], ['travellers', 'travelers'], ['cancelled', 'canceled'], ['cancelling', 'canceling'],
    ['labelled', 'labeled'], ['modelling', 'modeling'], ['jewellery', 'jewelry'], ['defence', 'defense'], ['offence', 'offense'], ['pyjamas', 'pajamas'], ['plough', 'plow'], ['mould', 'mold'], ['mouldy', 'moldy'],
    ['sceptical', 'skeptical'], ['sceptic', 'skeptic'], ['catalogue', 'catalog'], ['aeroplane', 'airplane'], ['enrol', 'enroll'], ['fulfil', 'fulfill'], ['skilful', 'skillful'], ['wilful', 'willful'], ['aluminium', 'aluminum'],
    ['mum', 'mom'], ['mummy', 'mommy'], ['sulphur', 'sulfur'], ['moustache', 'mustache'], ['manoeuvre', 'maneuver'], ['manoeuvred', 'maneuvered'], ['towards', 'toward'], ['whilst', 'while'], ['amongst', 'among'],
    ['marvellous', 'marvelous'], ['fuelled', 'fueled'], ['dialled', 'dialed'], ['quarrelled', 'quarreled'], ['signalled', 'signaled'], ['woollen', 'woolen'], ['ageing', 'aging'], ['judgement', 'judgment'], ['programme', 'program'], ['practise', 'practice'], ['licence', 'license'], ['tyre', 'tire'], ['kerb', 'curb'], ['cheque', 'check'], ['storey', 'story'], ['draught', 'draft'], ['pram', 'stroller']])
    PAIRS.push(pr);
  // only pairs that are spelling differences, not words with their own meaning in the other dialect
  const AMBIG = new Set(['judgement', 'practise', 'licence', 'tyre', 'kerb', 'cheque', 'storey', 'draught', 'pram', 'programme', 'towards', 'whilst', 'amongst', 'mum', 'mummy']);
  const UK = new Map(), US = new Map();
  for (const [u, us] of PAIRS) { if (AMBIG.has(u)) continue; UK.set(u, us); US.set(us, u); }
  // count both styles in a chapter's text
  function spellingIndex(fullText) {
    let uk = 0, us = 0; const seen = { uk: new Map(), us: new Map() };
    for (const m of fullText.toLowerCase().matchAll(/[a-z]+/g)) {
      const t = m[0];
      if (UK.has(t)) { uk++; seen.uk.set(t, (seen.uk.get(t) || 0) + 1); }
      else if (US.has(t)) { us++; seen.us.set(t, (seen.us.get(t) || 0) + 1); }
    }
    return { uk, us, seen };
  }

  // ---------------------------------------------------------------- run the checks on one paragraph
  // ctx: { spelling: spellingIndex(), prefer: 'uk' | 'us' }
  function check(text, ctx = {}) {
    const out = [];
    const dlg = dialogueRanges(text);
    // a / an
    for (const m of text.matchAll(/\b(a|an|A|An|AN)\s+([\p{L}\p{N}][\p{L}\p{N}'’.-]*)/gu)) {
      const art = m[1], word = m[2];
      if (/^[A-Z]$/.test(word) || word.length < 2 && !/\d/.test(word)) continue;         // “plan A”, single letters
      if (m.index > 0 && /[\p{L}'’]/u.test(text[m.index - 1])) continue;
      if (art === 'A' && m.index > 0 && !/[\s“"(]/.test(text[m.index - 1])) continue;
      const an = needsAn(word);
      if (an === null) continue;
      if (an && art.toLowerCase() === 'a') out.push({ cat: 'grammar', start: m.index, end: m.index + art.length, msg: `Use “an” before a vowel sound (“an ${word}”).`, fix: keepCase(art, 'an') });
      if (!an && art.toLowerCase() === 'an') out.push({ cat: 'grammar', start: m.index, end: m.index + art.length, msg: `Use “a” before a consonant sound (“a ${word}”).`, fix: keepCase(art, 'a') });
    }
    for (const r of R) {
      r.re.lastIndex = 0;
      let m;
      while ((m = r.re.exec(text))) {
        if (m[0] === '') { r.re.lastIndex++; continue; }
        if (r.notInDialogue && inside(dlg, m.index)) continue;
        if (r.guard && !r.guard(text, m, ctx)) continue;
        const fix = r.repl(m);
        if (fix === m[0]) continue;
        out.push({ cat: r.cat, start: m.index, end: m.index + m[0].length, msg: r.msg, fix });
      }
    }
    // UK / US mixing
    const sp = ctx.spelling;
    if (sp && sp.uk && sp.us) {
      const prefer = ctx.prefer || (sp.uk >= sp.us ? 'uk' : 'us');
      const other = prefer === 'uk' ? US : UK;
      for (const m of text.matchAll(/[A-Za-z]+/g)) {
        const t = m[0].toLowerCase();
        if (!other.has(t)) continue;
        const rep = other.get(t);
        out.push({ cat: 'spelling', start: m.index, end: m.index + m[0].length, msg: `This chapter mixes ${prefer === 'uk' ? 'UK and US' : 'US and UK'} spellings. You mostly write “${rep}”${prefer === 'uk' ? ' (UK / Australian spelling)' : ' (US spelling)'}.`, fix: keepCase(m[0], rep) });
      }
    }
    // overlapping hits: keep the first / longest
    out.sort((a, b) => a.start - b.start || b.end - a.end);
    const kept = []; let lastEnd = -1;
    for (const o of out) { if (o.start >= lastEnd) { kept.push(o); lastEnd = o.end; } }
    return kept;
  }

  return { check, spellingIndex, needsAn, dialogueRanges, _rules: R };
})();
